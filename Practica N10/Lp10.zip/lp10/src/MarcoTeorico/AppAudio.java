package MarcoTeorico;

import javax.sound.sampled.*;
import javax.swing.*;
import java.io.File;
import java.io.IOException;

public class AppAudio {

    public static void main(String[] args) {

        JFrame frame = new JFrame("Reproducción de Audio");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 200);

        JButton playButton = new JButton("Reproducir Audio");

        // Ruta específica de tu archivo
        String audioPath = "/Users/algyusc/eclipse-workspace/lp10/src/MarcoTeorico/Acustic.wav";

        playButton.addActionListener(e -> playAudio(audioPath));

        frame.add(playButton);
        frame.setVisible(true);
    }

    public static void playAudio(String filePath) {
        try {
            File audioFile = new File(filePath);

            if (!audioFile.exists()) {
                JOptionPane.showMessageDialog(null, "El archivo no existe: " + filePath);
                return;
            }

            AudioInputStream audioStream = AudioSystem.getAudioInputStream(audioFile);
            Clip clip = AudioSystem.getClip();
            clip.open(audioStream);
            clip.start();

            clip.addLineListener(event -> {
                if (event.getType() == LineEvent.Type.STOP) {
                    clip.close();
                }
            });

        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al reproducir el audio: " + e.getMessage());
        }
    }
}
