//package MarcoTeorico;
//
//import javafx.application.Platform;
//import javafx.embed.swing.JFXPanel;
//import javafx.scene.Scene;
//import javafx.scene.media.Media;
//import javafx.scene.media.MediaPlayer;
//import javafx.scene.media.MediaView;
//import javax.swing.*;
//import java.io.File;
//
//public class VideoExample {
//
//    public static void main(String[] args) {
//
//        JFrame frame = new JFrame("Reproducción de Video");
//        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        frame.setSize(800, 600);
//
//        // Panel que permite integrar JavaFX dentro de Swing
//        JFXPanel jfxPanel = new JFXPanel();
//        frame.add(jfxPanel);
//
//        frame.setVisible(true);
//
//        // Ejecutar JavaFX en su propio hilo
//        Platform.runLater(() -> {
//
//            // Cambia aquí la ruta de tu archivo de video:
//            String videoPath = new File("ruta_del_video.mp4").toURI().toString();
//
//            Media media = new Media(videoPath);
//            MediaPlayer mediaPlayer = new MediaPlayer(media);
//            MediaView mediaView = new MediaView(mediaPlayer);
//
//            // Crear escena de JavaFX dentro del JFXPanel
//            Scene scene = new Scene(new javafx.scene.Group(mediaView));
//            jfxPanel.setScene(scene);
//
//            mediaPlayer.play();
//        });
//    }
//}

