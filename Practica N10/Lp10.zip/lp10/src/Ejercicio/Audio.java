package Ejercicio;

import javax.sound.sampled.*;
import java.io.File;

public class Audio {

    public static void reproducir(String ruta) {
        try {
            File archivo = new File(ruta);

            if (!archivo.exists()) {
                System.out.println("No se encontró: " + ruta);
                return;
            }

            AudioInputStream audio = AudioSystem.getAudioInputStream(archivo);
            Clip clip = AudioSystem.getClip();

            clip.open(audio);
            clip.start();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
