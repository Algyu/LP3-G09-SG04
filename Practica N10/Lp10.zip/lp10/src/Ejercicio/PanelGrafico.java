package Ejercicio;

import javax.swing.*;
import java.awt.*;

public class PanelGrafico extends JPanel {

    private int[] datos;

    public PanelGrafico(int[] datos) {
        this.datos = datos;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int ancho = getWidth();
        int alto = getHeight();

        int margen = 50;
        int espacioX = (ancho - 2 * margen) / 6;

        g2.setColor(Color.YELLOW);

        for (int i = 0; i < 7; i++) {

            int x = margen + (espacioX * i);
            int y = alto - margen - datos[i];

            g2.setColor(Color.RED);
            g2.fillOval(x - 4, y - 4, 8, 8);

            if (i < 6) {
                int x2 = margen + (espacioX * (i + 1));
                int y2 = alto - margen - datos[i + 1];

                g2.setColor(Color.YELLOW);
                g2.drawLine(x, y, x2, y2);
            }
        }

        g2.setColor(Color.BLACK);
        g2.drawString("temperatura en la semana", 20, 20);
    }
}


