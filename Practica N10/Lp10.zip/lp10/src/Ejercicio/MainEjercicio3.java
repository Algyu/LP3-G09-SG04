package Ejercicio;

import javax.swing.*;
import java.awt.*;

public class MainEjercicio3 extends JFrame {

    public MainEjercicio3() {

        super("Reproductor de Efectos de Sonido");

        setSize(350, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setLayout(new GridLayout(3, 1, 10, 15));

        String base = "/Users/algyusc/eclipse-workspace/lp10/src/Ejercicio/";

        JButton btnCampana = new JButton("Campana");
        JButton btnExplosion = new JButton("Explosion");
        JButton btnAplauso = new JButton("Aplauso");

        btnCampana.addActionListener(e ->
                Audio.reproducir(base + "Campana.wav"));

        btnExplosion.addActionListener(e ->
                Audio.reproducir(base + "Explosion.wav"));

        btnAplauso.addActionListener(e ->
                Audio.reproducir(base + "Aplauso.wav"));

        add(btnCampana);
        add(btnExplosion);
        add(btnAplauso);

        setVisible(true);
    }

    public static void main(String[] args) {
        new MainEjercicio3();
    }
}