package Ejercicio;

import javax.swing.*;
import java.awt.*;

public class MainEjercicio2 extends JFrame {

    private JTextField[] campos = new JTextField[7];
    private int[] temperaturas = new int[7];
    private PanelGrafico panel;

    public MainEjercicio2() {

        super("Registro de Temperaturas");

        setSize(700, 550);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        panel = new PanelGrafico(temperaturas);
        add(panel, BorderLayout.CENTER);

        JPanel panelInferior = new JPanel();
        panelInferior.setLayout(new GridLayout(8, 2, 10, 8)); 

        String[] dias = {"Lunes", "Martes", "Miércoles", "Jueves",
                         "Viernes", "Sábado", "Domingo"};

        for (int i = 0; i < 7; i++) {
            panelInferior.add(new JLabel(dias[i] + ":"));
            campos[i] = new JTextField(10);
            panelInferior.add(campos[i]);
        }

        JButton btnMostrar = new JButton("Mostrar Gráfico");
        panelInferior.add(btnMostrar);
        panelInferior.add(new JLabel(""));

        add(panelInferior, BorderLayout.SOUTH);

        btnMostrar.addActionListener(e -> {
            for (int i = 0; i < 7; i++) {
                try {
                    temperaturas[i] = Integer.parseInt(campos[i].getText());
                } catch (NumberFormatException ex) {
                    temperaturas[i] = 0;
                }
            }
            panel.repaint();
        });

        setVisible(true);
    }

    public static void main(String[] args) {
        new MainEjercicio2();
    }
}


