package Ejercicio;

import javax.swing.*;
import java.awt.*;

public class MainEjercicio4 extends JFrame {

    public MainEjercicio4() {

        super("Control de Música");

        setSize(400, 250);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setLayout(new GridLayout(3, 1, 10, 15));

        String rutaMusica = "/Users/algyusc/eclipse-workspace/lp10/src/Ejercicio/Acustic.wav";

        ControlAudio control = new ControlAudio(rutaMusica);

        JButton btnReproducir = new JButton("Reproducir");
        JButton btnPausar = new JButton("Pausar");
        JButton btnReanudar = new JButton("Reanudar");

        btnReproducir.addActionListener(e -> control.reproducir());
        btnPausar.addActionListener(e -> control.pausar());
        btnReanudar.addActionListener(e -> control.reanudar());

        add(btnReproducir);
        add(btnPausar);
        add(btnReanudar);

        setVisible(true);
    }

    public static void main(String[] args) {
        new MainEjercicio4();
    }
}


