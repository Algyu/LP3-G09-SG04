package Ejercicio;

import javax.sound.sampled.*;
import java.io.File;

public class ControlAudio {

    private Clip clip;
    private long posicionPausa = 0;

    public ControlAudio(String ruta) {
        try {
            File archivo = new File(ruta);
            AudioInputStream audio = AudioSystem.getAudioInputStream(archivo);
            clip = AudioSystem.getClip();
            clip.open(audio);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void reproducir() {
        if (clip != null) {
            clip.stop();
            clip.setMicrosecondPosition(0);
            posicionPausa = 0;
            clip.start();
        }
    }

    public void pausar() {
        if (clip != null && clip.isRunning()) {
            posicionPausa = clip.getMicrosecondPosition();
            clip.stop();
        }
    }

    public void reanudar() {
        if (clip != null && !clip.isRunning()) {
            clip.setMicrosecondPosition(posicionPausa);
            clip.start();
        }
    }
}


