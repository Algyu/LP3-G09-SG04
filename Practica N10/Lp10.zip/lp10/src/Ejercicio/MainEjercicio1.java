package Ejercicio;

import javax.swing.*;
import java.awt.*;

public class MainEjercicio1 {

    public static void main(String[] args) {

        JFrame frame = new JFrame("Ventana de Gestion");
        frame.setSize(380, 380);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        frame.setLayout(new FlowLayout(FlowLayout.CENTER, 15, 15));

        Articulo producto = new Articulo("Sin nombre", 0.0, 0, "Ninguna");

        JTextField txtCategoria = new JTextField(15);
        JTextField txtNombre = new JTextField(15);
        JTextField txtPrecio = new JTextField(15);
        JTextField txtStock = new JTextField(15);

        JButton btnActualizar = new JButton("Actualizar el articulo");
        JLabel lblResultado = new JLabel("La info del articulo aparecera aqui");

        btnActualizar.addActionListener(e -> {

            producto.setCategoria(txtCategoria.getText());
            producto.setNombre(txtNombre.getText());

            try {
                double precio = Double.parseDouble(txtPrecio.getText());
                producto.setPrecio(precio);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(frame, "Precio invalido");
            }

            try {
                int cantidad = Integer.parseInt(txtStock.getText());
                producto.setCantidadStock(cantidad);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(frame, "Cantidad invalida");
            }

            lblResultado.setText(
                "<html><b>Articulo:</b> " + producto.getNombre() +
                "<br><b>Monto:</b> " + producto.getPrecio() +
                "<br><b>Stock:</b> " + producto.getCantidadStock() +
                "<br><b>Categoria:</b> " + producto.getCategoria() + "</html>"
            );
        });

        frame.add(new JLabel("categoria:"));
        frame.add(txtCategoria);

        frame.add(new JLabel("nombre:"));
        frame.add(txtNombre);

        frame.add(new JLabel("monto:"));
        frame.add(txtPrecio);

        frame.add(new JLabel("cantidad:"));
        frame.add(txtStock);

        frame.add(btnActualizar);
        frame.add(lblResultado);

        frame.setVisible(true);
    }
}
