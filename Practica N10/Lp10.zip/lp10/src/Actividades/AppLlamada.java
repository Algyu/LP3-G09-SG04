package Actividades;

import javax.sound.sampled.*;
import javax.swing.*;
import java.io.File;

public class AppLlamada {

    public static void main(String[] args) {

        JFrame frame = new JFrame("Sonido de Llamada");
        frame.setSize(300, 150);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JButton llamada = new JButton("Reproducir Llamada");

        String rutaAudio = "/Users/algyusc/eclipse-workspace/lp10/src/Actividades/llamada.wav";

        llamada.addActionListener(e -> reproducir(rutaAudio));

        frame.setLayout(new java.awt.FlowLayout());
        frame.add(llamada);
        frame.setVisible(true);
    }

    public static void reproducir(String ruta) {
        try {
            File archivo = new File(ruta);

            if (!archivo.exists()) {
                JOptionPane.showMessageDialog(null, "No se encontró el archivo:\n" + ruta);
                return;
            }

            AudioInputStream audio = AudioSystem.getAudioInputStream(archivo);
            Clip clip = AudioSystem.getClip();
            clip.open(audio);
            clip.start();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}

