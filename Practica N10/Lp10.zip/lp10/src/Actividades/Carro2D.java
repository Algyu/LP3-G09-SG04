package Actividades;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.AffineTransform;

public class Carro2D extends JPanel {

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        AffineTransform base = g2.getTransform();

        g2.translate(150, 120);

        g2.rotate(Math.toRadians(-10)); 

        g2.scale(1.3, 1.3);

        dibujarCarro(g2);

        g2.setTransform(base);
    }

    private void dibujarCarro(Graphics2D g2) {

        g2.setColor(new Color(200, 0, 0));
        g2.fillRect(0, 20, 120, 40);

        int[] px = {15, 45, 75, 105};
        int[] py = {20, 0, 0, 20};
        g2.fillPolygon(px, py, 4);

        g2.setColor(Color.CYAN);
        g2.fillRect(50, 3, 25, 15);

        g2.setColor(Color.BLACK);
        g2.fillOval(20, 50, 25, 25);
        g2.fillOval(75, 50, 25, 25);
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Carro Avanzado con Graphics2D");
        frame.setSize(450, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(new Carro2D());
        frame.setVisible(true);
    }
}


