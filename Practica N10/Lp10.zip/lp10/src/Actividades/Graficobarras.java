package Actividades;

import javax.swing.*;
import java.awt.*;

public class Graficobarras extends JPanel {

    private String[] categorias = {"Ene", "Feb", "Mar", "Abr"};
    private int[] valores = {80, 150, 60, 120};

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int alturaBarra = 30;
        int espacio = 20;
        int margenIzq = 100;
        int margenSuperior = 40;
        int anchoMaximo = 300;

        int max = 0;
        for (int v : valores) {
            if (v > max) max = v;
        }

        for (int i = 0; i < valores.length; i++) {
            int ancho = (int) ((double) valores[i] / max * anchoMaximo);
            int y = margenSuperior + i * (alturaBarra + espacio);

            g2.setColor(new Color(120, 160, 220));
            g2.fillRect(margenIzq, y, ancho, alturaBarra);
            g2.setColor(Color.BLACK);
            g2.drawString(valores[i] + "", margenIzq + ancho + 10, y + alturaBarra - 5);
            g2.drawString(categorias[i], 20, y + alturaBarra - 5);
        }

        g2.drawString("Ventas (unidades)", margenIzq, margenSuperior - 10);
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Gráfico de Barras Horizontal");
        frame.setSize(500, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(new Graficobarras());
        frame.setVisible(true);
    }
}

