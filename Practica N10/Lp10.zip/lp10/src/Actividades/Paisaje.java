package Actividades;

import javax.swing.*;
import java.awt.*;

public class Paisaje extends JPanel {

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        g2.setColor(new Color(135, 206, 235));
        g2.fillRect(0, 0, getWidth(), getHeight());

        g2.setColor(new Color(60, 180, 60));
        g2.fillRect(0, 250, getWidth(), 150);

        g2.setColor(Color.YELLOW);
        g2.fillOval(300, 20, 60, 60);

        g2.setColor(new Color(90, 90, 90));
        int[] x = {50, 150, 250};
        int[] y = {250, 120, 250};
        g2.fillPolygon(x, y, 3);

        g2.setColor(new Color(100, 50, 20));
        g2.fillRect(80, 200, 20, 50);

        g2.setColor(new Color(20, 120, 20));
        g2.fillOval(60, 150, 60, 60);
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Paisaje Simple");
        frame.setSize(400, 350);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(new Paisaje());
        frame.setVisible(true);
    }
}


