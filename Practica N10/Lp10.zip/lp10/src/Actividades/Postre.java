package Actividades;

public class Postre {
    private String nombre;
    private double precio;
    private int calorias;

    public Postre(String nombre, double precio, int calorias) {
        this.nombre = nombre;
        this.precio = precio;
        this.calorias = calorias;
    }

    public String getNombre() { return nombre; }
    public void setNombre(String n) { this.nombre = n; }

    public double getPrecio() { return precio; }
    public void setPrecio(double p) { this.precio = p; }

    public int getCalorias() { return calorias; }
    public void setCalorias(int c) { this.calorias = c; }
}
