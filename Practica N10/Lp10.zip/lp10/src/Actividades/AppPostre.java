package Actividades;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;

import javax.swing.*;
import java.awt.*;

public class AppPostre {

    public static void main(String[] args) {

        JFrame frame = new JFrame("Binding de Postre");
        frame.setSize(300, 250);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new FlowLayout());

        Postre postre = new Postre("Cheesecake", 12.50, 420);

        JTextField fieldNombre = new JTextField(postre.getNombre(), 15);
        JTextField fieldPrecio = new JTextField(String.valueOf(postre.getPrecio()), 15);
        JTextField fieldCalorias = new JTextField(String.valueOf(postre.getCalorias()), 15);

        JButton actualizar = new JButton("Actualizar");

        actualizar.addActionListener(e -> {
            postre.setNombre(fieldNombre.getText());
            try {
                postre.setPrecio(Double.parseDouble(fieldPrecio.getText()));
                postre.setCalorias(Integer.parseInt(fieldCalorias.getText()));
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(frame, "Datos numéricos inválidos");
            }

            System.out.println("Postre actualizado:");
            System.out.println("Nombre: " + postre.getNombre());
            System.out.println("Precio: " + postre.getPrecio());
            System.out.println("Calorías: " + postre.getCalorias());
        });

        frame.add(new JLabel("Nombre:"));
        frame.add(fieldNombre);
        frame.add(new JLabel("Precio:"));
        frame.add(fieldPrecio);
        frame.add(new JLabel("Calorías:"));
        frame.add(fieldCalorias);
        frame.add(actualizar);

        frame.setVisible(true);
    }
}


