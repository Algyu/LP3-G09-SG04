package MarcoTeorico1;

import javax.swing.JFrame;

public class App6 {
    public static void main(String[] args) {
        MarcoDemoTeclas marcoDemoTeclas = new MarcoDemoTeclas();
        marcoDemoTeclas.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        marcoDemoTeclas.setSize(350, 150);
        marcoDemoTeclas.setVisible(true);
    }
}

