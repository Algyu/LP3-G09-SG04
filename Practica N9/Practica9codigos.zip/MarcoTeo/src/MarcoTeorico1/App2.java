package MarcoTeorico1;

import javax.swing.JFrame;
public class App2
{
	public static void main(String[] args)
	{
		LabelFrame marcoEtiqueta = new LabelFrame();
		marcoEtiqueta.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		marcoEtiqueta.setSize(260, 180);
		marcoEtiqueta.setVisible(true);
	}
}