package MarcoTeorico1;

import java.awt.FlowLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.Icon;
import javax.swing.ImageIcon;

public class LabelFrame extends JFrame
{
    private JLabel etiqueta1; 
    private JLabel etiqueta2;
    private JLabel etiqueta3; 

    public LabelFrame()
    {
        super("Prueba de JLabel");
        setLayout(new FlowLayout()); 
        
        etiqueta1 = new JLabel("Etiqueta con texto");
        etiqueta1.setToolTipText("Esta es etiqueta1");
        add(etiqueta1);

        Icon icono = new ImageIcon("/Users/algyusc/eclipse-workspace/MarcoTeo/src/MarcoTeorico1/insecto.png");

        etiqueta2 = new JLabel("Etiqueta con icono", icono, SwingConstants.LEFT);
        etiqueta2.setToolTipText("Esta es etiqueta2");
        add(etiqueta2);

        etiqueta3 = new JLabel();
        etiqueta3.setText("Etiqueta con icono y texto abajo");
        etiqueta3.setIcon(icono);
        etiqueta3.setHorizontalTextPosition(SwingConstants.CENTER);
        etiqueta3.setVerticalTextPosition(SwingConstants.BOTTOM);
        etiqueta3.setToolTipText("Esta es etiqueta3");
        add(etiqueta3);
    }
}

