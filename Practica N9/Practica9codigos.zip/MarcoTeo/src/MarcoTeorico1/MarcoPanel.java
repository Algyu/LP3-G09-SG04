package MarcoTeorico1;

import java.awt.GridLayout;
import java.awt.BorderLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;

public class MarcoPanel extends JFrame {

    private final JPanel panelBotones;
    private final JButton[] botones;

    public MarcoPanel() {
        super("Demostracion de Panel");

        botones = new JButton[5];
        panelBotones = new JPanel();
        panelBotones.setLayout(new GridLayout(1, botones.length));

        for (int i = 0; i < botones.length; i++) {
            botones[i] = new JButton("Boton " + (i + 1));
            panelBotones.add(botones[i]);
        }

        add(panelBotones, BorderLayout.SOUTH);
    }
}

