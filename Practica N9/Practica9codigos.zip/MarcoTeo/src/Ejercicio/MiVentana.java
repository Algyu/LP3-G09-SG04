package Ejercicio;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.FlowLayout;

public class MiVentana extends JFrame {

    private JPanel contentPane;
    private JTextField txtNombre;

    public MiVentana() {
        setTitle("GUI creada con WindowBuilder pruebita");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        contentPane = new JPanel();
        contentPane.setLayout(new FlowLayout());
        setContentPane(contentPane);

        JLabel lbl = new JLabel("Nombre:");
        contentPane.add(lbl);
        
        JButton btnNewButton = new JButton("New button");
        contentPane.add(btnNewButton);

        txtNombre = new JTextField(10);
        contentPane.add(txtNombre);

        JButton btn = new JButton("Aceptar");
        contentPane.add(btn);
    }
}

