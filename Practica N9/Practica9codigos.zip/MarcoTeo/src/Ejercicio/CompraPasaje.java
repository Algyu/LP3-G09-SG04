package Ejercicio;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.time.LocalDate;

public class CompraPasaje extends JFrame {

    private JTextField txtNombre, txtDni, txtFecha;
    private JCheckBox chkAudifonos, chkManta, chkRevista;
    private JRadioButton rbPiso1, rbPiso2;
    private JComboBox<String> cbOrigen, cbDestino;
    private JList<String> listaCalidad;
    private JButton btnMostrar, btnLimpiar;

    public CompraPasaje() {

        setTitle("Compra de Pasaje – Grupo Salas");
        setSize(450, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        add(new JLabel("Nombre:"));
        txtNombre = new JTextField(15);
        add(txtNombre);

        add(new JLabel("DNI:"));
        txtDni = new JTextField(10);
        add(txtDni);

        add(new JLabel("Fecha de viaje (dd/mm/aaaa):"));
        txtFecha = new JTextField(10);
        add(txtFecha);

        add(new JLabel("Servicios opcionales:"));
        chkAudifonos = new JCheckBox("Audífonos");
        chkManta = new JCheckBox("Manta");
        chkRevista = new JCheckBox("Revista");
        add(chkAudifonos);
        add(chkManta);
        add(chkRevista);

        add(new JLabel("Piso del bus:"));
        rbPiso1 = new JRadioButton("1er Piso");
        rbPiso2 = new JRadioButton("2do Piso");
        ButtonGroup grupoPisos = new ButtonGroup();
        grupoPisos.add(rbPiso1);
        grupoPisos.add(rbPiso2);
        add(rbPiso1);
        add(rbPiso2);

        add(new JLabel("Origen:"));
        cbOrigen = new JComboBox<>(new String[]{"Arequipa", "Lima", "Tacna"});
        add(cbOrigen);

        add(new JLabel("Destino:"));
        cbDestino = new JComboBox<>(new String[]{"Arequipa", "Lima", "Tacna"});
        add(cbDestino);

        add(new JLabel("Calidad de servicio:"));
        listaCalidad = new JList<>(new String[]{"Económico", "Standard", "VIP"});
        listaCalidad.setVisibleRowCount(3);
        add(new JScrollPane(listaCalidad));

        btnMostrar = new JButton("Ver resumen");
        btnLimpiar = new JButton("Limpiar");
        add(btnMostrar);
        add(btnLimpiar);


        btnMostrar.addActionListener(e -> {

            if (txtNombre.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Ingrese un nombre.");
                return;
            }

            String dni = txtDni.getText().trim();

            if (!dni.matches("[1-9][0-9]{7}")) {
                JOptionPane.showMessageDialog(
                        this,
                        "DNI inválido.\nDebe tener 8 dígitos, no empezar con 0 y ser solo números.",
                        "Error",
                        JOptionPane.ERROR_MESSAGE
                );
                return;
            }

            String fecha = txtFecha.getText().trim();

            if (!fecha.matches("\\d{2}/\\d{2}/\\d{4}")) {
                JOptionPane.showMessageDialog(
                        this,
                        "Formato de fecha incorrecto. Use: dd/mm/aaaa",
                        "Error",
                        JOptionPane.ERROR_MESSAGE
                );
                return;
            }

            try {
                String[] p = fecha.split("/");
                int d = Integer.parseInt(p[0]);
                int m = Integer.parseInt(p[1]);
                int a = Integer.parseInt(p[2]);

                LocalDate hoy = LocalDate.now();
                LocalDate fv = LocalDate.of(a, m, d);

                if (fv.isBefore(hoy)) {
                    JOptionPane.showMessageDialog(
                            this,
                            "La fecha de viaje no puede ser anterior a hoy.",
                            "Fecha inválida",
                            JOptionPane.ERROR_MESSAGE
                    );
                    return;
                }

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(
                        this,
                        "La fecha ingresada no es válida.",
                        "Error",
                        JOptionPane.ERROR_MESSAGE
                );
                return;
            }

            String servicios = "";
            if (chkAudifonos.isSelected()) servicios += "Audífonos ";
            if (chkManta.isSelected()) servicios += "Manta ";
            if (chkRevista.isSelected()) servicios += "Revista ";
            if (servicios.isEmpty()) servicios = "Ninguno";

            String piso = rbPiso1.isSelected() ? "1er Piso"
                    : rbPiso2.isSelected() ? "2do Piso"
                    : "No seleccionado";

            String calidad = listaCalidad.getSelectedValue();
            if (calidad == null) calidad = "No seleccionado";

            String resumen =
                    "Nombre: " + txtNombre.getText() +
                    "\nDNI: " + dni +
                    "\nFecha de viaje: " + fecha +
                    "\nOrigen: " + cbOrigen.getSelectedItem() +
                    "\nDestino: " + cbDestino.getSelectedItem() +
                    "\nPiso: " + piso +
                    "\nServicios: " + servicios +
                    "\nCalidad: " + calidad;

            JOptionPane.showMessageDialog(this, resumen, "Resumen del Pasajero", JOptionPane.INFORMATION_MESSAGE);
        });

        btnLimpiar.addActionListener(e -> {
            txtNombre.setText("");
            txtDni.setText("");
            txtFecha.setText("");

            chkAudifonos.setSelected(false);
            chkManta.setSelected(false);
            chkRevista.setSelected(false);

            grupoPisos.clearSelection();

            cbOrigen.setSelectedIndex(0);
            cbDestino.setSelectedIndex(0);

            listaCalidad.clearSelection();
        });
    }

    public static void main(String[] args) {
        new CompraPasaje().setVisible(true);
    }
}