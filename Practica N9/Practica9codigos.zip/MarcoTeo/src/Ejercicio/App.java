package Ejercicio;

public class App {
    public static void main(String[] args) {
        MiVentana ventana = new MiVentana();
        ventana.setVisible(true);
    }
}

