package Actividad;

import java.awt.FlowLayout;
import java.awt.Container;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JFrame;

public class FlowLayoutDemo extends JFrame {

    private final JButton btnIzquierda;
    private final JButton btnCentro;
    private final JButton btnDerecha;
    private final FlowLayout layout;
    private final Container contenedor;

    public FlowLayoutDemo() {
        super("FlowLayout - Grupo: Salas, Coaguila");

        layout = new FlowLayout();
        contenedor = getContentPane();
        setLayout(layout);

        btnIzquierda = new JButton("Izquierda");
        add(btnIzquierda);
        btnIzquierda.addActionListener(
            new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    layout.setAlignment(FlowLayout.LEFT);
                    layout.layoutContainer(contenedor);
                }
            }
        );

        btnCentro = new JButton("Centro");
        add(btnCentro);
        btnCentro.addActionListener(
            new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    layout.setAlignment(FlowLayout.CENTER);
                    layout.layoutContainer(contenedor);
                }
            }
        );

        btnDerecha = new JButton("Derecha");
        add(btnDerecha);
        btnDerecha.addActionListener(
            new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    layout.setAlignment(FlowLayout.RIGHT);
                    layout.layoutContainer(contenedor);
                }
            }
        );
    }
}
