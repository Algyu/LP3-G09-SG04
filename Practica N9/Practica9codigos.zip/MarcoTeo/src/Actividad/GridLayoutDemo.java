package Actividad;

import java.awt.GridLayout;
import java.awt.Container;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JFrame;

public class GridLayoutDemo extends JFrame implements ActionListener {

    private final JButton[] botones;
    private static final String[] nombres = {"uno", "dos", "tres", "cuatro", "cinco", "seis"};
    private boolean alternar = true;

    private final Container contenedor;
    private final GridLayout grid1;
    private final GridLayout grid2;

    public GridLayoutDemo() {
        super("GridLayout - Grupo: Salas, Coaguila");

        grid1 = new GridLayout(2, 3, 5, 5);
        grid2 = new GridLayout(3, 2);

        contenedor = getContentPane();
        setLayout(grid1);

        botones = new JButton[nombres.length];

        for (int i = 0; i < nombres.length; i++) {
            botones[i] = new JButton(nombres[i]);
            botones[i].addActionListener(this);
            add(botones[i]);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (alternar)
            contenedor.setLayout(grid2);
        else
            contenedor.setLayout(grid1);

        alternar = !alternar;
        contenedor.validate(); 
    }
}
