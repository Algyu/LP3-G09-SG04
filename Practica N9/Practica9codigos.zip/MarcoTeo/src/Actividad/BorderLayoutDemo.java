package Actividad;

import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JFrame;

public class BorderLayoutDemo extends JFrame implements ActionListener {

    private final JButton[] botones;
    private static final String[] nombres = {
        "Ocultar Norte", "Ocultar Sur", "Ocultar Este", "Ocultar Oeste", "Ocultar Centro"
    };
    private final BorderLayout layout;

    public BorderLayoutDemo() {
        super("BorderLayout - Grupo: Salas, Coaguila");

        layout = new BorderLayout(5, 5);
        setLayout(layout);

        botones = new JButton[nombres.length];

        for (int i = 0; i < nombres.length; i++) {
            botones[i] = new JButton(nombres[i]);
            botones[i].addActionListener(this);
        }

        add(botones[0], BorderLayout.NORTH);
        add(botones[1], BorderLayout.SOUTH);
        add(botones[2], BorderLayout.EAST);
        add(botones[3], BorderLayout.WEST);
        add(botones[4], BorderLayout.CENTER);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        for (JButton b : botones) {
            if (e.getSource() == b)
                b.setVisible(false);
            else
                b.setVisible(true);
        }

        layout.layoutContainer(getContentPane());
    }
}
