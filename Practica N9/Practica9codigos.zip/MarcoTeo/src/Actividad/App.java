package Actividad;

import javax.swing.JFrame;

public class App {
    public static void main(String[] args) {

        FlowLayoutDemo fl = new FlowLayoutDemo();
        fl.setSize(350, 150);
        fl.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        fl.setVisible(true);

        BorderLayoutDemo bl = new BorderLayoutDemo();
        bl.setSize(400, 250);
        bl.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        bl.setVisible(true);

        GridLayoutDemo gl = new GridLayoutDemo();
        gl.setSize(350, 200);
        gl.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        gl.setVisible(true);
    }
}
