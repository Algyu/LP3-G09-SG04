package Ejercicio1;

public class Main {
    public static void main(String[] args) {
        CarritoModelo modelo = new CarritoModelo();
        CarritoVista vista = new CarritoVista();
        CarritoControlador control = new CarritoControlador(modelo, vista);
        control.iniciar();
    }
}
