package Ejercicio2;

public class Item {
    private String nombre;
    private String tipo;
    private String descripcion;
    private int cantidad;

    public Item(String nombre, String tipo, String descripcion, int cantidad) {
        this.nombre = nombre;
        this.tipo = tipo;
        this.descripcion = descripcion;
        this.cantidad = cantidad;
    }

    public String getNombre() { return nombre; }
    public int getCantidad() { return cantidad; }

    @Override
    public String toString() {
        return nombre + " (" + tipo + ") - " + descripcion + " x" + cantidad;
    }
}

