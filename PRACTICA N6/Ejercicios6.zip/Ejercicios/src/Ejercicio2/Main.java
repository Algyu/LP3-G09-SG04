package Ejercicio2;

public class Main {
    public static void main(String[] args) {
        InventarioModel modelo = new InventarioModel();
        InventarioView vista = new InventarioView();
        InventarioController ctrl = new InventarioController(modelo, vista);
        ctrl.ejecutar();
    }
}

