package Ejercicio2;

import java.util.ArrayList;

public class InventarioModel {
    private ArrayList<Item> lista = new ArrayList<>();

    public void agregarItem(Item i) { lista.add(i); }
    public void eliminarItem(int pos) { if (pos >= 0 && pos < lista.size()) lista.remove(pos); }
    public ArrayList<Item> obtenerItems() { return lista; }

    public ArrayList<Item> buscarItem(String palabra) {
        ArrayList<Item> r = new ArrayList<>();
        for (Item i : lista) {
            if (i.getNombre().toLowerCase().contains(palabra.toLowerCase())) r.add(i);
        }
        return r;
    }
}

