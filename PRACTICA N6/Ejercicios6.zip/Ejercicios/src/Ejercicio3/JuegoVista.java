package Ejercicio3;

import java.util.List;
import java.util.Scanner;

public class JuegoVista {
    Scanner sc = new Scanner(System.in);

    public void mostrarEstado(Jugador j, List<Enemigo> enemigos) {
        System.out.println("\nJugador: " + j.getNombre() + " | Salud: " + j.getSalud());
        for (Enemigo e : enemigos) {
            System.out.println("- " + e.getNombre() + " (" + e.getSalud() + " HP)");
        }
    }

    public void mostrarMensaje(String msg) {
        System.out.println(msg);
    }

    public void menu() {
        System.out.println("\n1. Atacar enemigo");
        System.out.println("2. Salir del combate");
        System.out.print("Opción: ");
    }

    public int elegirEnemigo() {
        System.out.print("Número del enemigo: ");
        return Integer.parseInt(sc.nextLine());
    }
}

