package Ejercicio3;

public class Main {
    public static void main(String[] args) {
        Jugador jugador = new Jugador("Héroe");
        JuegoVista vista = new JuegoVista();
        JuegoControlador control = new JuegoControlador(jugador, vista);
        control.iniciarCombate();
    }
}

