package Ejercicio3;

public class Jugador {
    private String nombre;
    private int salud;
    private int nivel;

    public Jugador(String nombre) {
        this.nombre = nombre;
        this.salud = 100;
        this.nivel = 1;
    }

    public String getNombre() { return nombre; }
    public int getSalud() { return salud; }

    public void atacar(Enemigo e) {
        int daño = 10 * nivel;
        e.recibirDaño(daño);
    }

    public void recibirDaño(int d) {
        salud -= d;
        if (salud < 0) salud = 0;
    }
}