package Ejercicio3;

import java.util.ArrayList;

public class JuegoControlador {
    private Jugador jugador;
    private ArrayList<Enemigo> enemigos;
    private JuegoVista vista;

    public JuegoControlador(Jugador j, JuegoVista v) {
        this.jugador = j;
        this.vista = v;
        enemigos = new ArrayList<>();
        enemigos.add(new Enemigo("Goblin", 1, "Tierra"));
        enemigos.add(new Enemigo("Orco", 2, "Fuego"));
    }

    public void iniciarCombate() {
        boolean activo = true;
        java.util.Scanner sc = new java.util.Scanner(System.in);

        while (activo && jugador.getSalud() > 0 && !enemigos.isEmpty()) {
            vista.mostrarEstado(jugador, enemigos);
            vista.menu();
            String op = sc.nextLine();

            switch (op) {
                case "1":
                    vista.mostrarEstado(jugador, enemigos);
                    int num = vista.elegirEnemigo();
                    if (num >= 0 && num < enemigos.size()) {
                        Enemigo ene = enemigos.get(num);
                        jugador.atacar(ene);
                        vista.mostrarMensaje("Atacaste a " + ene.getNombre());
                        if (ene.getSalud() <= 0) {
                            vista.mostrarMensaje(ene.getNombre() + " fue derrotado!");
                            enemigos.remove(ene);
                        }
                        for (Enemigo e : enemigos) {
                            e.atacar(jugador);
                            vista.mostrarMensaje(e.getNombre() + " te atacó!");
                        }
                    } else vista.mostrarMensaje("Enemigo inválido.");
                    break;
                case "2":
                    activo = false;
                    vista.mostrarMensaje("Te retiraste del combate.");
                    break;
            }
        }

        if (jugador.getSalud() <= 0)
            vista.mostrarMensaje("Has sido derrotado...");
        else if (enemigos.isEmpty())
            vista.mostrarMensaje("¡Ganaste el combate!");
    }
}

