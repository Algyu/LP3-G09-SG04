package Ejercicio3;

public class Enemigo {
    private String nombre;
    private int salud;
    private int nivel;
    private String tipo;

    public Enemigo(String nombre, int nivel, String tipo) {
        this.nombre = nombre;
        this.nivel = nivel;
        this.tipo = tipo;
        this.salud = 50 + (nivel * 10);
    }

    public String getNombre() { return nombre; }
    public int getSalud() { return salud; }

    public void atacar(Jugador j) {
        int daño = (int)(Math.random() * (nivel * 5 + 5));
        j.recibirDaño(daño);
    }

    public void recibirDaño(int d) {
        salud -= d;
        if (salud < 0) salud = 0;
    }
}

