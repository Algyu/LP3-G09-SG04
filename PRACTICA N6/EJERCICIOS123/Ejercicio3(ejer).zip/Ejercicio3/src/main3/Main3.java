package main3;


import Modelo3.Jugador;
import Vista3.JuegoVista;
import Controlador3.JuegoControlador;

public class Main3 {
    public static void main(String[] args) {
        Jugador jugador = new Jugador("Héroe");
        JuegoVista vista = new JuegoVista();
        JuegoControlador control = new JuegoControlador(jugador, vista);

        control.iniciarCombate();
    }
}
