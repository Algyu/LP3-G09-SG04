package main2; 

import Modelo2.InventarioModel;
import VIsta2.InventarioView;
import Controlador2.InventarioController;

public class Main {
    public static void main(String[] args) {
        InventarioModel modelo = new InventarioModel();
        InventarioView vista = new InventarioView();
        InventarioController ctrl = new InventarioController(modelo, vista);
        ctrl.ejecutar();
    }
}
