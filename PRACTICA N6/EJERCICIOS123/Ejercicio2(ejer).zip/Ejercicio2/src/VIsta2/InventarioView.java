package VIsta2;

import java.util.ArrayList;
import java.util.Scanner;
import Modelo2.Item;


public class InventarioView {
    Scanner sc = new Scanner(System.in);

    public String pedirTexto(String msg) {
        System.out.print(msg + ": ");
        return sc.nextLine();
    }

    public int pedirNumero(String msg) {
        System.out.print(msg + ": ");
        return Integer.parseInt(sc.nextLine());
    }

    public void mostrarItems(ArrayList<Item> items) {
        if (items.isEmpty()) System.out.println("No hay ítems.");
        else for (int i = 0; i < items.size(); i++) System.out.println(i + ". " + items.get(i));
    }

    public void menu() {
        System.out.println("\n1. Agregar ítem");
        System.out.println("2. Eliminar ítem");
        System.out.println("3. Ver inventario");
        System.out.println("4. Buscar ítem");
        System.out.println("5. Salir");
        System.out.print("Opción: ");
    }

    public void mensaje(String m) { System.out.println(m); }
}

