package Controlador2;

import Modelo2.InventarioModel;
import Modelo2.Item;
import VIsta2.InventarioView;

import java.util.Scanner;

public class InventarioController {
    private InventarioModel modelo;
    private InventarioView vista;

    public InventarioController(InventarioModel modelo, InventarioView vista) {
        this.modelo = modelo;
        this.vista = vista;
    }

    public void ejecutar() {
        boolean activo = true;
        java.util.Scanner sc = new java.util.Scanner(System.in);

        while (activo) {
            vista.menu();
            String op = sc.nextLine();
            switch (op) {
                case "1":
                    String nom = vista.pedirTexto("Nombre");
                    String tipo = vista.pedirTexto("Tipo");
                    String desc = vista.pedirTexto("Descripción");
                    int cant = vista.pedirNumero("Cantidad");
                    modelo.agregarItem(new Item(nom, tipo, desc, cant));
                    vista.mensaje("Agregado correctamente.");
                    break;
                case "2":
                    vista.mostrarItems(modelo.obtenerItems());
                    int pos = vista.pedirNumero("Número del ítem");
                    modelo.eliminarItem(pos);
                    vista.mensaje("Ítem eliminado.");
                    break;
                case "3":
                    vista.mostrarItems(modelo.obtenerItems());
                    break;
                case "4":
                    String busc = vista.pedirTexto("Buscar");
                    vista.mostrarItems(modelo.buscarItem(busc));
                    break;
                case "5":
                    activo = false;
                    vista.mensaje("Saliendo...");
                    break;
                default:
                    vista.mensaje("Opción no válida.");
            }
        }
    }
}
