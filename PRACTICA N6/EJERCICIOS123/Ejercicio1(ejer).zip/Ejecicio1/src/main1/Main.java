package main1;

import modelo1.CarritoModelo;
import vista1.CarritoVista;
import controlador1.CarritoControlador;

public class Main {
 public static void main(String[] args) {
     CarritoModelo modelo = new CarritoModelo();
     CarritoVista vista = new CarritoVista();
     CarritoControlador controlador = new CarritoControlador(modelo, vista);
     controlador.iniciar();
 }
}

