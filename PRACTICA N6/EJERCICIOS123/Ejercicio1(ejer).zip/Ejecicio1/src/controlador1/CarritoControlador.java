package controlador1;

import modelo1.CarritoModelo;
import vista1.CarritoVista;
import modelo1.Producto;


public class CarritoControlador {
    private CarritoModelo modelo;
    private CarritoVista vista;

    public CarritoControlador(CarritoModelo modelo, CarritoVista vista) {
        this.modelo = modelo;
        this.vista = vista;
    }

    public void iniciar() {
        boolean activo = true;
        java.util.Scanner sc = new java.util.Scanner(System.in);

        while (activo) {
            vista.mostrarMenu();
            String op = sc.nextLine();

            switch (op) {
                case "1":
                    String nom = vista.pedirNombre();
                    double pre = vista.pedirPrecio();
                    modelo.agregarAlCarrito(new Producto(nom, pre));
                    vista.mostrarMensaje("Producto agregado.");
                    break;
                case "2":
                    vista.mostrarProductos(modelo.obtenerCarrito());
                    break;
                case "3":
                    vista.mostrarProductos(modelo.obtenerCarrito());
                    int i = vista.pedirIndice();
                    modelo.eliminarDelCarrito(i);
                    vista.mostrarMensaje("Eliminado.");
                    break;
                case "4":
                    double desc = vista.pedirDescuento();
                    modelo.aplicarDescuento(desc);
                    vista.mostrarMensaje("Descuento aplicado.");
                    break;
                case "5":
                    vista.mostrarMensaje("Total a pagar: S/ " + modelo.calcularTotal());
                    break;
                case "6":
                    modelo.finalizarCompra();
                    vista.mostrarMensaje("Compra realizada!");
                    break;
                case "7":
                    vista.mostrarMensaje("Historial de compras:");
                    for (var compra : modelo.getHistorial()) {
                        vista.mostrarProductos(compra);
                        System.out.println("--");
                    }
                    break;
                case "8":
                    activo = false;
                    break;
                default:
                    vista.mostrarMensaje("Opción inválida.");
            }
        }
    }
}