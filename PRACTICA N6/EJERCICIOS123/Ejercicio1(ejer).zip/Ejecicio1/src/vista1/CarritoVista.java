package vista1;

import java.util.ArrayList;
import java.util.Scanner;
import modelo1.Producto;


public class CarritoVista {
    Scanner sc = new Scanner(System.in);

    public String pedirNombre() {
        System.out.print("Nombre del producto: ");
        return sc.nextLine();
    }

    public double pedirPrecio() {
        System.out.print("Precio del producto: ");
        return Double.parseDouble(sc.nextLine());
    }

    public void mostrarProductos(ArrayList<Producto> lista) {
        if (lista.isEmpty()) {
            System.out.println("No hay productos.");
        } else {
            for (int i = 0; i < lista.size(); i++) {
                System.out.println(i + ". " + lista.get(i));
            }
        }
    }

    public int pedirIndice() {
        System.out.print("Número del producto: ");
        return Integer.parseInt(sc.nextLine());
    }

    public double pedirDescuento() {
        System.out.print("Porcentaje de descuento: ");
        return Double.parseDouble(sc.nextLine());
    }

    public void mostrarMenu() {
        System.out.println("\n=== MENÚ CARRITO ===");
        System.out.println("1. Agregar producto");
        System.out.println("2. Ver carrito");
        System.out.println("3. Eliminar producto");
        System.out.println("4. Aplicar descuento");
        System.out.println("5. Calcular total");
        System.out.println("6. Finalizar compra");
        System.out.println("7. Ver historial");
        System.out.println("8. Salir");
        System.out.print("Opción: ");
    }

    public void mostrarMensaje(String msg) {
        System.out.println(msg);
    }
}

