package modelo1;

import java.util.ArrayList;

public class CarritoModelo {
    private ArrayList<Producto> carrito = new ArrayList<>();
    private ArrayList<ArrayList<Producto>> historial = new ArrayList<>();

    public void agregarAlCarrito(Producto p) {
        carrito.add(p);
    }

    public void eliminarDelCarrito(int pos) {
        if (pos >= 0 && pos < carrito.size()) carrito.remove(pos);
    }

    public ArrayList<Producto> obtenerCarrito() {
        return carrito;
    }

    public double calcularTotal() {
        double total = 0;
        for (Producto p : carrito) total += p.getPrecio();
        return total;
    }

    public void aplicarDescuento(double porc) {
        for (Producto p : carrito) {
            double nuevo = p.getPrecio() * (1 - porc / 100);
            carrito.set(carrito.indexOf(p), new Producto(p.getNombre(), nuevo));
        }
    }

    public void finalizarCompra() {
        historial.add(new ArrayList<>(carrito));
        carrito.clear();
    }

    public ArrayList<ArrayList<Producto>> getHistorial() {
        return historial;
    }
}
