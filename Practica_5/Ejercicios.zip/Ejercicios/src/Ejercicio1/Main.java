package Ejercicio1;

public class Main {
    public static <F, S> void imprimirPar(Par<F, S> par) {
        System.out.println(par);
    }

    public static void main(String[] args) {
        Par<String, Integer> p1 = new Par<>("Edad", 22);
        Par<Double, Boolean> p2 = new Par<>(3.14, true);

        class Persona {
            String nombre;
            Persona(String nombre) { this.nombre = nombre; }
            @Override
            public String toString() { return nombre; }
        }

        Par<Persona, Integer> p3 = new Par<>(new Persona("Alexandra"), 1);

        imprimirPar(p1);
        imprimirPar(p2);
        imprimirPar(p3);
    }
}

