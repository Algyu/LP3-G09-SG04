package Ejercicio1;

public class PruebaContenedor {
    public static void main(String[] args) {
        Contenedor<String, Integer> cont = new Contenedor<>();

        cont.agregarPar("ID", 1001);
        cont.agregarPar("Edad", 22);
        cont.agregarPar("Año", 2025);

        System.out.println("Mostrando pares del contenedor:");
        cont.mostrarPares();

        System.out.println("Obteniendo el segundo par: " + cont.obtenerPar(1));
    }
}

