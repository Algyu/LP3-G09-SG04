package Ejercicio1;

import java.util.ArrayList;

public class Contenedor<F, S> {
    private ArrayList<Par<F, S>> lista = new ArrayList<>();

    public void agregarPar(F primero, S segundo) {
        lista.add(new Par<>(primero, segundo));
    }

    public Par<F, S> obtenerPar(int indice) {
        return lista.get(indice);
    }

    public ArrayList<Par<F, S>> obtenerTodosLosPares() {
        return lista;
    }

    public void mostrarPares() {
        for (Par<F, S> par : lista) {
            System.out.println(par);
        }
    }
}

