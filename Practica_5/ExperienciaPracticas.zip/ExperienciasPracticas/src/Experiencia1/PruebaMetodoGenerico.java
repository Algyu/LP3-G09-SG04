package Experiencia1;

public class PruebaMetodoGenerico {

    public static <E> void imprimirArreglo(E[] arregloEntrada) {
        for (E elemento : arregloEntrada) {
            System.out.print(elemento + " ");
        }
        System.out.println();
    }

    public static <E> int imprimirArreglo(E[] arregloEntrada, int inicio, int fin) throws Exception {
        if (inicio < 0 || fin >= arregloEntrada.length || inicio >= fin) {
            throw new Exception("Índices fuera de rango");
        }
        int cantidad = 0;
        for (int i = inicio; i <= fin; i++) {
            System.out.print(arregloEntrada[i] + " ");
            cantidad++;
        }
        System.out.println();
        return cantidad;
    }

    public static void main(String[] args) {
        Integer[] arregloEnteros = {1, 2, 3, 4, 5};
        String[] arregloTextos = {"uno", "dos", "tres", "cuatro"};

        System.out.println("Arreglo completo:");
        imprimirArreglo(arregloEnteros);

        System.out.println("Arreglo por rango:");
        try {
            imprimirArreglo(arregloTextos, 1, 2);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}