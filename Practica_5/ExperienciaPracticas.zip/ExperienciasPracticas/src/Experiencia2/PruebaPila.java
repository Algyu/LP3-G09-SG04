package Experiencia2;

public class PruebaPila {
    public static void main(String[] args) {
        Pila<Integer> pilaNumeros = new Pila<>(5);
        pilaNumeros.push(10);
        pilaNumeros.push(20);
        pilaNumeros.push(30);

        System.out.println("¿La pila contiene 20?: " + pilaNumeros.contains(20));
        System.out.println("Sacando: " + pilaNumeros.pop());
        System.out.println("Sacando: " + pilaNumeros.pop());
    }
}