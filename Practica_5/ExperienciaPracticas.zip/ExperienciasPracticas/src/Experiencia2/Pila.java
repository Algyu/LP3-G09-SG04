package Experiencia2;

public class Pila<E> {
    private E[] elementos;
    private int tope;

    @SuppressWarnings("unchecked")
    public Pila(int capacidad) {
        elementos = (E[]) new Object[capacidad];
        tope = -1;
    }

    public void push(E valor) {
        if (tope == elementos.length - 1) {
            throw new RuntimeException("La pila está llena");
        }
        elementos[++tope] = valor;
    }

    public E pop() {
        if (tope == -1) {
            throw new RuntimeException("La pila está vacía");
        }
        return elementos[tope--];
    }

    public int getTope() {
        return tope;
    }

    public E getElemento(int indice) {
        if (indice < 0 || indice > tope) {
            throw new IndexOutOfBoundsException("Índice fuera de rango");
        }
        return elementos[indice];
    }
}

