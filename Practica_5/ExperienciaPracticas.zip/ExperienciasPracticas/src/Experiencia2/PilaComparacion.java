package Experiencia2;

public class PilaComparacion<E> extends Pila<E> {

    public PilaComparacion(int capacidad) {
        super(capacidad);
    }

    public boolean esIgual(PilaComparacion<E> otra) {
        if (this.getTope() != otra.getTope()) {
            return false;
        }
        for (int i = 0; i <= this.getTope(); i++) {
            if (!this.getElemento(i).equals(otra.getElemento(i))) {
                return false;
            }
        }
        return true;
    }
}


