package Experiencia2;

public class PruebaIgualdad {
    public static void main(String[] args) {
        PilaComparacion<String> pila1 = new PilaComparacion<>(5);
        PilaComparacion<String> pila2 = new PilaComparacion<>(5);

        pila1.push("A");
        pila1.push("B");
        pila2.push("A");
        pila2.push("B");

        System.out.println("¿Son iguales?: " + pila1.esIgual(pila2));

        pila2.pop();
        System.out.println("¿Son iguales ahora?: " + pila1.esIgual(pila2));
    }
}


