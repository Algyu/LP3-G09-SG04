package Actividad3;

public class Habitacion {
 public void reservar() {
     System.out.println("Habitación reservada.");
 }
}