package Actividad3;

public class Suite extends Habitacion {
 @Override
 public void reservar() {
     System.out.println("Suite reservada con desayuno incluido.");
 }
}

