package Actividad3;

public class Economica extends Habitacion {
 @Override
 public void reservar() {
     System.out.println("Habitación económica reservada.");
 }
}
