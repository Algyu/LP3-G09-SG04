package Actividad3;

public class MainExp3 {
 public static void main(String[] args) {
     Habitacion h1 = new Habitacion();
     Habitacion h2 = new Suite();
     Habitacion h3 = new Economica();

     h1.reservar();
     h2.reservar();
     h3.reservar();
 }
}
