package Actividad5;

public class NotificadorSMS implements CanalNotificacion {
 public void enviar(String mensaje) {
     System.out.println("SMS enviado: " + mensaje);
 }
}
