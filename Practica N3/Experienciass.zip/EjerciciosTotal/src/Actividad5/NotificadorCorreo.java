package Actividad5;

public class NotificadorCorreo implements CanalNotificacion {
 public void enviar(String mensaje) {
     System.out.println("Correo enviado: " + mensaje);
 }
}

