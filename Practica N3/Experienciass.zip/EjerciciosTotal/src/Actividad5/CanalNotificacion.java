package Actividad5;

public interface CanalNotificacion {
 void enviar(String mensaje);
}
