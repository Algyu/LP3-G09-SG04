package Actividad5;

public class MainExp5 {
 public static void main(String[] args) {
     NotificadorReserva n1 = new NotificadorReserva(new NotificadorCorreo());
     NotificadorReserva n2 = new NotificadorReserva(new NotificadorSMS());

     n1.notificar("Reserva confirmada para Ana");
     n2.notificar("Reserva confirmada para Luis");
 }
}

