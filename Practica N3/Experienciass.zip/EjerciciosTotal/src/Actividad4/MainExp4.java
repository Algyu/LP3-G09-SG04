package Actividad4;

public class MainExp4 {
 public static void main(String[] args) {
     HabitacionEstandar h1 = new HabitacionEstandar();
     HabitacionPremium h2 = new HabitacionPremium();

     h1.limpiar();
     h2.limpiar();
     h2.pedirComida();
 }
}

