package Actividad4;

public interface ServicioLimpieza {
 void limpiar();
}

