package Actividad4;

public interface ServicioComida {
 void pedirComida();
}

