package Actividad4;

public class HabitacionEstandar implements ServicioLimpieza {
 public void limpiar() {
     System.out.println("Se limpió la habitación estándar.");
 }
}

