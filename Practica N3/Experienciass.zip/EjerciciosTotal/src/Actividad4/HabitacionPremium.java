package Actividad4;

public class HabitacionPremium implements ServicioLimpieza, ServicioComida {
 public void limpiar() {
     System.out.println("Se limpió la habitación premium.");
 }
 public void pedirComida() {
     System.out.println("Comida pedida a la habitación premium.");
 }
}

