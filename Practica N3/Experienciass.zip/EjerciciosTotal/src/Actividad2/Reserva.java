package Actividad2;

public class Reserva {
 private String cliente;
 private PoliticaCancelacion politica;

 public Reserva(String cliente, PoliticaCancelacion politica) {
     this.cliente = cliente;
     this.politica = politica;
 }

 public boolean cancelar(int diasAntes) {
     return politica.puedeCancelar(diasAntes);
 }

 public String getCliente() {
     return cliente;
 }
}

