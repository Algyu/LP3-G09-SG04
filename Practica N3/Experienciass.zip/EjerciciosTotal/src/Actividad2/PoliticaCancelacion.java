package Actividad2;

public interface PoliticaCancelacion {
    boolean puedeCancelar(int diasAntes);
}
