package Actividad2;

public class PoliticaEstricta implements PoliticaCancelacion {
 public boolean puedeCancelar(int diasAntes) {
     return false;
 }
}

