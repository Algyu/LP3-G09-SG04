package Actividad2;

public class PoliticaFlexible implements PoliticaCancelacion {
 public boolean puedeCancelar(int diasAntes) {
     return diasAntes >= 1;
 }
}

