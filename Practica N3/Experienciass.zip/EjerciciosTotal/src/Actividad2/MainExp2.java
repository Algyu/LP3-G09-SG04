package Actividad2;

public class MainExp2 {
 public static void main(String[] args) {
     Reserva r1 = new Reserva("Ana", new PoliticaFlexible());
     Reserva r2 = new Reserva("Luis", new PoliticaModerada());
     Reserva r3 = new Reserva("Pedro", new PoliticaEstricta());

     System.out.println("Ana cancelar con 2 días: " + r1.cancelar(2));
     System.out.println("Luis cancelar con 2 días: " + r2.cancelar(2));
     System.out.println("Pedro cancelar con 5 días: " + r3.cancelar(5));
 }
}