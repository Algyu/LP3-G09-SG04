package Actividad2;

public class PoliticaModerada implements PoliticaCancelacion {
 public boolean puedeCancelar(int diasAntes) {
     return diasAntes >= 3;
 }
}

