package Actividad1;

public class MainExp1 {
 public static void main(String[] args) {
     Habitacion h1 = new Habitacion(101, "Doble");
     GestorDisponibilidadHabitacion gestor = new GestorDisponibilidadHabitacion();

     System.out.println("Disponible al inicio: " + h1.isDisponible());
     gestor.reservar(h1);
     System.out.println("Disponible ahora: " + h1.isDisponible());
     gestor.liberar(h1);
     System.out.println("Disponible al final: " + h1.isDisponible());
 }
}

