package Actividad1;

public class GestorDisponibilidadHabitacion {
 public void reservar(Habitacion h) {
     h.setDisponible(false);
     System.out.println("Habitación " + h.getNumero() + " reservada.");
 }

 public void liberar(Habitacion h) {
     h.setDisponible(true);
     System.out.println("Habitación " + h.getNumero() + " liberada.");
 }
}

