package Ejercicio3;

public class Coche extends Vehiculo {
 @Override
 public void acelerar() {
     System.out.println("El coche acelera usando el motor.");
 }
}
