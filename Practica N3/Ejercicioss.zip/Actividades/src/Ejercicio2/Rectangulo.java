package Ejercicio2;

public class Rectangulo implements Forma {
 @Override
 public void dibujar() {
     System.out.println("Dibujando un rectangulo.");
 }
}