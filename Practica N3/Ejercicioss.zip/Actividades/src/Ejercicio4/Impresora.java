package Ejercicio4;

public class Impresora implements Imprimible {
 @Override
 public void imprimir() {
     System.out.println("Imprimiendo documento...");
 }
}
