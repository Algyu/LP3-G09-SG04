package Ejercicio4;

public class ImpresoraMultifuncional implements Imprimible, Escaneable {
 @Override
 public void imprimir() {
     System.out.println("Imprimiendo con multifuncional...");
 }

 @Override
 public void escanear() {
     System.out.println("Escaneando documento...");
 }
}
