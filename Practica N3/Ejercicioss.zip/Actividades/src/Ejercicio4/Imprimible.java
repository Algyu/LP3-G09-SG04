package Ejercicio4;

public interface Imprimible {
 void imprimir();
}
