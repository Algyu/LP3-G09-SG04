package Ejercicio4;

public interface Escaneable {
	void escanear();
}
