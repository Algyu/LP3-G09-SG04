package Ejercicio3;

public class Bicicleta extends Vehiculo {
	@Override
	public void acelerar() {
		System.out.println("La bicicleta acelera pedaleando.");
	}
}
