package Ejercicio3;

public abstract class Vehiculo {
    public abstract void acelerar();
}

