package Ejercicio2;

public interface Forma {
	 void dibujar();
}
