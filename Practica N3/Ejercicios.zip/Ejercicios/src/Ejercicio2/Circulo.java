package Ejercicio2;

public class Circulo implements Forma {
	@Override
	public void dibujar() {
		System.out.println("Dibujando un circulo.");
	}
}

