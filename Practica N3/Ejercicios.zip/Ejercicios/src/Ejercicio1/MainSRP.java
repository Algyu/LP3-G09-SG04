package Ejercicio1;

public class MainSRP {
	public static void main(String[] args) {
		Empleado emp = new Empleado("Carlos", 24000, "TI");
		CalculadoraPago calc = new CalculadoraPago();
		System.out.println("Pago mensual: " + calc.calcularPagoMensual(emp));
	}
}