package Acti6;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class PruebaSerializacion {
    public static void main(String[] args) {
        String ruta = "/Users/algyusc/Downloads/LP/alumnos.dat";

        Alumno a1 = new Alumno("Carlos Mendoza", "78451236", "A001", new Fecha(12, 5, 2002));
        Alumno a2 = new Alumno("Lucía Ramos", "74125896", "A002", new Fecha(3, 9, 2003));
        Alumno a3 = new Alumno("Andrés Silva", "79845612", "A003", new Fecha(27, 11, 2001));

        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(ruta))) {
            salida.writeObject(a1);
            salida.writeObject(a2);
            salida.writeObject(a3);
            System.out.println("Los objetos fueron guardados correctamente en el archivo alumnos.dat");
        } catch (IOException e) {
            System.out.println("Error al escribir el archivo: " + e.getMessage());
        }
    }
}
