package Acti6;

import java.io.Serializable;

public class Alumno extends Persona implements Serializable {
    private String codigo;
    private Fecha fechaNacimiento;

    public Alumno(String nombre, String dni, String codigo, Fecha fechaNacimiento) {
        super(nombre, dni);
        this.codigo = codigo;
        this.fechaNacimiento = fechaNacimiento;
    }

    @Override
    public String toString() {
        return super.toString() + ", Código: " + codigo + ", Fecha de Nacimiento: " + fechaNacimiento;
    }
}

