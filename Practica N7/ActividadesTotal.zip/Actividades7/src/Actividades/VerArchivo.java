package Actividades;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class VerArchivo {
    public static void main(String[] args) {
        FileInputStream archivo = null;
        byte[] buffer = new byte[1024];

        try {
            archivo = new FileInputStream("/Users/algyusc/Downloads/LP/TestFile.java");

            int bytesLeidos = archivo.read(buffer);
            if (bytesLeidos != -1) {
                String contenido = new String(buffer, 0, bytesLeidos);
                System.out.println("=== Contenido del archivo ===\n");
                System.out.println(contenido);
            } else {
                System.out.println("El archivo está vacío.");
            }

        } catch (FileNotFoundException e) {
            System.out.println("No se encontró el archivo: " + e.getMessage());
        } catch (IOException e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
        } finally {
            try {
                if (archivo != null) archivo.close();
            } catch (IOException e) {
                System.out.println("Error al cerrar el archivo: " + e.getMessage());
            }
        }
    }
}

