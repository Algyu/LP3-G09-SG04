package Actividades;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class AgendaContactos {
    public static void main(String[] args) {
        String rutaArchivo = "/Users/algyusc/Downloads/LP/agenda.txt"; 
        String[][] agenda = new String[50][3]; 
        int contador = 0;

        try (BufferedReader lector = new BufferedReader(new FileReader(rutaArchivo))) {
            String linea;

            while ((linea = lector.readLine()) != null && contador < 50) {
                String[] datos = linea.split(",");
                if (datos.length == 3) {
                    agenda[contador][0] = datos[0].trim();
                    agenda[contador][1] = datos[1].trim();
                    agenda[contador][2] = datos[2].trim();
                    contador++;
                }
            }

        } catch (IOException e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
            return;
        }

        if (contador == 0) {
            System.out.println("La agenda está vacía o no se encontró el archivo.");
            return;
        }

        Scanner entrada = new Scanner(System.in);
        System.out.print("Ingrese el nombre del contacto a buscar: ");
        String nombreBuscar = entrada.nextLine().trim().toLowerCase();

        boolean encontrado = false;

        for (int i = 0; i < contador; i++) {
            if (agenda[i][0].toLowerCase().equals(nombreBuscar)) {
                System.out.println("\nContacto encontrado:");
                System.out.println("Nombre: " + agenda[i][0]);
                System.out.println("Teléfono: " + agenda[i][1]);
                System.out.println("Dirección: " + agenda[i][2]);
                encontrado = true;
                break;
            }
        }

        if (!encontrado) {
            System.out.println("\nEl contacto no se encuentra en la agenda.");
        }
    }
}