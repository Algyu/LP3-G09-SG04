package Actividades;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class EscribirArchivo {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        String texto;

        try (PrintWriter salida = new PrintWriter(new FileWriter("datos.txt", true))) {
            System.out.println("Ingrese texto. Para finalizar escriba la palabra FIN:");
            texto = entrada.nextLine();

            while (!texto.equalsIgnoreCase("FIN")) {
                salida.println(texto);
                texto = entrada.nextLine();
            }

            System.out.println("Los datos fueron guardados correctamente en el archivo datos.txt");
        } catch (IOException e) {
            System.out.println("Error al escribir en el archivo: " + e.getMessage());
        }
    }
}

