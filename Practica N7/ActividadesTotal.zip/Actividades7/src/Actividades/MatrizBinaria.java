package Actividades;

import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class MatrizBinaria {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        FileOutputStream archivo = null;
        DataOutputStream salida = null;

        double[][] matriz;
        int filas, columnas;

        do {
            System.out.print("Ingrese el número de filas: ");
            filas = entrada.nextInt();
        } while (filas <= 0);

        do {
            System.out.print("Ingrese el número de columnas: ");
            columnas = entrada.nextInt();
        } while (columnas <= 0);

        matriz = new double[filas][columnas];

        System.out.println("\nIngrese los valores de la matriz:");
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                System.out.print("Elemento [" + i + "][" + j + "]: ");
                matriz[i][j] = entrada.nextDouble();
            }
        }

        try {
            archivo = new FileOutputStream("/Users/algyusc/Downloads/LP/matriz.dat");
            salida = new DataOutputStream(archivo);

            salida.writeInt(filas);
            salida.writeInt(columnas);

            for (int i = 0; i < filas; i++) {
                for (int j = 0; j < columnas; j++) {
                    salida.writeDouble(matriz[i][j]);
                }
            }

            System.out.println("\nLa matriz se guardó correctamente en el archivo matriz.dat");
        } catch (IOException e) {
            System.out.println("Error al guardar el archivo: " + e.getMessage());
        } finally {
            try {
                if (salida != null) salida.close();
                if (archivo != null) archivo.close();
            } catch (IOException e) {
                System.out.println("Error al cerrar el archivo: " + e.getMessage());
            }
        }
    }
}

