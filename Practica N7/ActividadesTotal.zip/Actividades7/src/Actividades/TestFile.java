package Actividades;

import java.io.IOException;
import java.nio.file.*;
import java.util.Scanner;

public class TestFile {
    public static void main(String[] args) throws IOException {
        Scanner entrada = new Scanner(System.in);
        System.out.print("Ingrese el nombre del archivo o directorio: ");
        
        Path ruta = Paths.get(entrada.nextLine());
        
        if (Files.exists(ruta)) {
            System.out.println("\nInformación del archivo o directorio:");
            System.out.println("Nombre: " + ruta.getFileName());
            System.out.println("¿Es un directorio?: " + (Files.isDirectory(ruta) ? "Sí" : "No"));
            System.out.println("¿Es una ruta absoluta?: " + (ruta.isAbsolute() ? "Sí" : "No"));
            System.out.println("Última modificación: " + Files.getLastModifiedTime(ruta));
            System.out.println("Tamaño: " + Files.size(ruta) + " bytes");
            System.out.println("Ruta: " + ruta);
            System.out.println("Ruta absoluta: " + ruta.toAbsolutePath());
            
            if (Files.isDirectory(ruta)) {
                System.out.println("\nContenido del directorio:");
                DirectoryStream<Path> contenido = Files.newDirectoryStream(ruta);
                for (Path p : contenido) {
                    System.out.println("- " + p.getFileName());
                }
            }
        } else {
            System.out.println("La ruta ingresada no existe.");
        }
    }
}