package Actividades;
import java.io.IOException;
import java.nio.file.*;
import java.util.Scanner;

public class InfoArchivoConsola {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        System.out.println("=== VISOR DE ARCHIVOS Y DIRECTORIOS ===");
        System.out.print("Ingrese la ruta del archivo o directorio: ");
        String textoRuta = entrada.nextLine();

        Path ruta = Paths.get(textoRuta);

        if (Files.exists(ruta)) {
            try {
                System.out.println("\nNombre: " + ruta.getFileName());
                System.out.println("¿Es un directorio?: " + (Files.isDirectory(ruta) ? "Sí" : "No"));
                System.out.println("¿Es una ruta absoluta?: " + (ruta.isAbsolute() ? "Sí" : "No"));
                System.out.println("Última modificación: " + Files.getLastModifiedTime(ruta));
                System.out.println("Tamaño: " + Files.size(ruta) + " bytes");
                System.out.println("Ruta: " + ruta);
                System.out.println("Ruta absoluta: " + ruta.toAbsolutePath());

                if (Files.isDirectory(ruta)) {
                    System.out.println("\nContenido del directorio:");
                    DirectoryStream<Path> contenido = Files.newDirectoryStream(ruta);
                    for (Path p : contenido) {
                        System.out.println(" - " + p.getFileName());
                    }
                }
            } catch (IOException e) {
                System.out.println("Error al leer la información: " + e.getMessage());
            }
        } else {
            System.out.println("La ruta ingresada no existe.");
        }
    }
}


