package Ejer1;

import java.io.*;
import java.util.*;

public class Gestor {
    private ArrayList<Personaje> lista = new ArrayList<>();
    private final String archivo = "personajes.txt";
    private Random random = new Random();

    public Gestor() {
        cargarDatos();
        cargarPersonajesAleatorios();
    }

    private void cargarDatos() {
        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] datos = linea.split(" ");
                if (datos.length >= 5) {
                    String nombre = datos[0];
                    int vida = Integer.parseInt(datos[1]);
                    int ataque = Integer.parseInt(datos[2]);
                    int defensa = Integer.parseInt(datos[3]);
                    int alcance = Integer.parseInt(datos[4]);
                    int nivel = datos.length == 6 ? Integer.parseInt(datos[5]) : 1;
                    Personaje p = new Personaje(nombre, vida, ataque, defensa, alcance);
                    for (int i = 1; i < nivel; i++) p.subirNivel();
                    lista.add(p);
                }
            }
        } catch (IOException e) {
            System.out.println("Archivo no encontrado, se creará uno nuevo.");
        }
    }

    private void guardarDatos() {
        try (PrintWriter pw = new PrintWriter(new FileWriter(archivo))) {
            for (Personaje p : lista) pw.println(p.toString());
        } catch (IOException e) {
            System.out.println("Error al guardar datos: " + e.getMessage());
        }
    }

    private void cargarPersonajesAleatorios() {
        if (lista.isEmpty()) {
            String[] nombres = {"Mago", "Asesino", "Vikingo", "Dragón"};
            for (String n : nombres) {
                int vida = random.nextInt(5) + 2;
                int ataque = random.nextInt(5) + 2;
                int defensa = random.nextInt(5) + 1;
                int alcance = random.nextInt(5) + 1;
                lista.add(new Personaje(n, vida, ataque, defensa, alcance));
            }
            guardarDatos();
            System.out.println("Se cargaron personajes aleatorios por defecto.");
        }
    }

    public void mostrar() {
        if (lista.isEmpty()) {
            System.out.println("No hay personajes registrados.");
        } else {
            System.out.println("\n=== LISTA DE PERSONAJES ===");
            for (Personaje p : lista) System.out.println(p);
        }
    }

    public void filtrarPorAtributo(String atributo) {
        lista.sort((p1, p2) -> {
            return switch (atributo.toLowerCase()) {
                case "vida" -> p2.getVida() - p1.getVida();
                case "ataque" -> p2.getAtaque() - p1.getAtaque();
                case "defensa" -> p2.getDefensa() - p1.getDefensa();
                case "alcance" -> p2.getAlcance() - p1.getAlcance();
                default -> 0;
            };
        });
        mostrar();
    }

    public void agregar(Personaje p) {
        for (Personaje per : lista) {
            if (per.getNombre().equalsIgnoreCase(p.getNombre())) {
                System.out.println("Ese personaje ya existe.");
                return;
            }
        }
        lista.add(p);
        guardarDatos();
        System.out.println("Personaje agregado correctamente.");
    }

    public void eliminar(String nombre) {
        boolean eliminado = lista.removeIf(p -> p.getNombre().equalsIgnoreCase(nombre));
        if (eliminado) {
            guardarDatos();
            System.out.println("Personaje eliminado.");
        } else System.out.println("No se encontró ese personaje.");
    }

    public void actualizarAtributo(String nombre, String atributo, int nuevoValor) {
        for (Personaje p : lista) {
            if (p.getNombre().equalsIgnoreCase(nombre)) {
                switch (atributo.toLowerCase()) {
                    case "vida" -> p.setVida(nuevoValor);
                    case "ataque" -> p.setAtaque(nuevoValor);
                    case "defensa" -> p.setDefensa(nuevoValor);
                    case "alcance" -> p.setAlcance(nuevoValor);
                    default -> {
                        System.out.println("Atributo no válido.");
                        return;
                    }
                }
                guardarDatos();
                System.out.println("Atributo actualizado correctamente.");
                return;
            }
        }
        System.out.println("No se encontró ese personaje.");
    }

    public void mostrarEstadisticas() {
        if (lista.isEmpty()) {
            System.out.println("No hay personajes para mostrar estadísticas.");
            return;
        }

        double promVida = lista.stream().mapToInt(Personaje::getVida).average().orElse(0);
        double promAtaque = lista.stream().mapToInt(Personaje::getAtaque).average().orElse(0);
        double promDefensa = lista.stream().mapToInt(Personaje::getDefensa).average().orElse(0);
        double promAlcance = lista.stream().mapToInt(Personaje::getAlcance).average().orElse(0);

        System.out.println("\n=== ESTADÍSTICAS ===");
        System.out.println("Total de personajes: " + lista.size());
        System.out.printf("Vida promedio: %.2f%n", promVida);
        System.out.printf("Ataque promedio: %.2f%n", promAtaque);
        System.out.printf("Defensa promedio: %.2f%n", promDefensa);
        System.out.printf("Alcance promedio: %.2f%n", promAlcance);
    }

    public void importar(String rutaArchivo) {
        try (BufferedReader br = new BufferedReader(new FileReader(rutaArchivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] d = linea.split(" ");
                if (d.length == 5) {
                    lista.add(new Personaje(d[0],
                            Integer.parseInt(d[1]),
                            Integer.parseInt(d[2]),
                            Integer.parseInt(d[3]),
                            Integer.parseInt(d[4])));
                }
            }
            guardarDatos();
            System.out.println("Importación completada.");
        } catch (IOException e) {
            System.out.println("Error al importar: " + e.getMessage());
        }
    }
}
