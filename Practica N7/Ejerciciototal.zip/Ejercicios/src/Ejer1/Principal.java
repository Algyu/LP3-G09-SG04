package Ejer1;

import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Gestor gestor = new Gestor();
        int opcion;

        do {
            System.out.println("\n=== GESTOR DE PERSONAJES 2.0 ===");
            System.out.println("1. Ver personajes");
            System.out.println("2. Agregar personaje");
            System.out.println("3. Eliminar personaje");
            System.out.println("4. Filtrar por atributo");
            System.out.println("5. Actualizar un atributo");
            System.out.println("6. Mostrar estadísticas");
            System.out.println("7. Importar personajes desde archivo");
            System.out.println("8. Subir nivel a un personaje");
            System.out.println("9. Salir");
            System.out.print("Elija una opción: ");
            opcion = sc.nextInt();
            sc.nextLine();

            switch (opcion) {
                case 1 -> gestor.mostrar();
                case 2 -> {
                    System.out.print("Nombre: ");
                    String nombre = sc.nextLine();
                    System.out.print("Vida: "); int vida = sc.nextInt();
                    System.out.print("Ataque: "); int ataque = sc.nextInt();
                    System.out.print("Defensa: "); int defensa = sc.nextInt();
                    System.out.print("Alcance: "); int alcance = sc.nextInt();
                    gestor.agregar(new Personaje(nombre, vida, ataque, defensa, alcance));
                }
                case 3 -> {
                    System.out.print("Nombre a eliminar: ");
                    String nombre = sc.nextLine();
                    gestor.eliminar(nombre);
                }
                case 4 -> {
                    System.out.print("Atributo para ordenar (vida, ataque, defensa, alcance): ");
                    String atributo = sc.nextLine();
                    gestor.filtrarPorAtributo(atributo);
                }
                case 5 -> {
                    System.out.print("Nombre del personaje: ");
                    String nombre = sc.nextLine();
                    System.out.print("Atributo a modificar: ");
                    String atributo = sc.nextLine();
                    System.out.print("Nuevo valor: ");
                    int valor = sc.nextInt();
                    gestor.actualizarAtributo(nombre, atributo, valor);
                }
                case 6 -> gestor.mostrarEstadisticas();
                case 7 -> {
                    System.out.print("Ruta del archivo a importar: ");
                    String ruta = sc.nextLine();
                    gestor.importar(ruta);
                }
                case 8 -> {
                    System.out.print("Nombre del personaje: ");
                    String nombre = sc.nextLine();
                    gestor.actualizarAtributo(nombre, "nivel", 0); // Simula el nivel
                }
                case 9 -> System.out.println("Saliendo del programa...");
                default -> System.out.println("Opción no válida.");
            }
        } while (opcion != 9);
    }
}
