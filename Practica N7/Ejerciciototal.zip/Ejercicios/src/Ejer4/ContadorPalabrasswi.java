package Ejer4;

import java.io.*;
import java.util.*;

public class ContadorPalabrasswi {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Ingrese la ruta del archivo a analizar: ");
        String ruta = sc.nextLine();

        File archivo = new File(ruta);
        if (!archivo.exists()) {
            System.out.println("El archivo no existe.");
            return;
        }

        int totalLineas = 0, totalPalabras = 0, totalCaracteres = 0;
        Map<String, Integer> palabras = new HashMap<>();

        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                totalLineas++;
                totalCaracteres += linea.replaceAll("\r\n", "").length();

                String[] partes = linea.split("\\W+");
                for (String p : partes) {
                    if (!p.isEmpty()) {
                        p = p.toLowerCase();
                        totalPalabras++;
                        palabras.put(p, palabras.getOrDefault(p, 0) + 1);
                    }
                }
            }

            System.out.println("\n=== RESULTADOS DEL ARCHIVO ===");
            System.out.println("Archivo leído: " + archivo.getName());
            System.out.println("Total de líneas: " + totalLineas);
            System.out.println("Total de palabras: " + totalPalabras);
            System.out.println("Total de caracteres: " + totalCaracteres);

            double promedio = (double) totalPalabras / totalLineas;
            System.out.printf("Promedio de palabras por línea: %.2f%n", promedio);

            System.out.println("\n=== PALABRAS MÁS FRECUENTES ===");
            palabras.entrySet().stream()
                    .sorted((a, b) -> b.getValue() - a.getValue())
                    .limit(5)
                    .forEach(e -> System.out.println(e.getKey() + ": " + e.getValue()));

        } catch (IOException e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
        }
    }
}

