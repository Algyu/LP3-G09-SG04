package Ejer4;

import java.io.*;
import java.util.*;
import javax.swing.JFileChooser;

public class ContadorPalabras {
    public static void main(String[] args) {
        JFileChooser selector = new JFileChooser();
        System.out.println("Seleccione el archivo de texto para analizar...");

        int resultado = selector.showOpenDialog(null);
        if (resultado != JFileChooser.APPROVE_OPTION) {
            System.out.println("No se seleccionó ningún archivo. Programa finalizado.");
            return;
        }

        File archivo = selector.getSelectedFile();
        if (!archivo.exists()) {
            System.out.println("El archivo no existe.");
            return;
        }

        int totalLineas = 0, totalPalabras = 0, totalCaracteres = 0;
        Map<String, Integer> palabras = new HashMap<>();

        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                totalLineas++;
                totalCaracteres += linea.replaceAll("\r\n", "").length();

                String[] partes = linea.split("\\W+");
                for (String p : partes) {
                    if (!p.isEmpty()) {
                        p = p.toLowerCase();
                        totalPalabras++;
                        palabras.put(p, palabras.getOrDefault(p, 0) + 1);
                    }
                }
            }

            System.out.println("\n=== RESULTADOS DEL ARCHIVO ===");
            System.out.println("Archivo leído: " + archivo.getName());
            System.out.println("Total de líneas: " + totalLineas);
            System.out.println("Total de palabras: " + totalPalabras);
            System.out.println("Total de caracteres: " + totalCaracteres);

            double promedio = (double) totalPalabras / totalLineas;
            System.out.printf("Promedio de palabras por línea: %.2f%n", promedio);

            System.out.println("\n=== PALABRAS MÁS FRECUENTES ===");
            palabras.entrySet().stream()
                    .sorted((a, b) -> b.getValue() - a.getValue())
                    .limit(5)
                    .forEach(e -> System.out.println(e.getKey() + ": " + e.getValue()));

        } catch (IOException e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
        }
    }
}

