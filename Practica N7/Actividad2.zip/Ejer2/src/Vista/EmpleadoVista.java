package Vista;

import Modelo.Empleado;
import Controlador.EmpleadoControlador;
import java.util.Scanner;

public class EmpleadoVista {
    private EmpleadoControlador controlador;
    private Scanner sc = new Scanner(System.in);

    public EmpleadoVista(EmpleadoControlador controlador) {
        this.controlador = controlador;
    }

    public void mostrarMenu() {
        int opcion;
        do {
            System.out.println("\n=== SISTEMA DE EMPLEADOS (MVC) ===");
            System.out.println("1. Listar empleados");
            System.out.println("2. Agregar empleado");
            System.out.println("3. Buscar empleado por número");
            System.out.println("4. Eliminar empleado por número");
            System.out.println("5. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = sc.nextInt();
            sc.nextLine();

            switch (opcion) {
                case 1 -> controlador.listarEmpleados();
                case 2 -> agregar();
                case 3 -> buscar();
                case 4 -> eliminar();
                case 5 -> System.out.println("Saliendo del sistema...");
                default -> System.out.println("Opción no válida.");
            }
        } while (opcion != 5);
    }

    private void agregar() {
        try {
            System.out.print("Número: ");
            int numero = sc.nextInt();
            sc.nextLine();
            System.out.print("Nombre: ");
            String nombre = sc.nextLine();
            System.out.print("Sueldo: ");
            double sueldo = sc.nextDouble();

            Empleado e = new Empleado(numero, nombre, sueldo);
            controlador.agregarEmpleado(e);
        } catch (Exception e) {
            System.out.println("Error al ingresar los datos.");
            sc.nextLine();
        }
    }

    private void buscar() {
        System.out.print("Número del empleado: ");
        int numero = sc.nextInt();
        controlador.buscarEmpleado(numero);
    }

    private void eliminar() {
        System.out.print("Número del empleado a eliminar: ");
        int numero = sc.nextInt();
        controlador.eliminarEmpleado(numero);
    }
}

