package main;

import Controlador.EmpleadoControlador;
import Vista.EmpleadoVista;

public class Main {
    public static void main(String[] args) {
        EmpleadoControlador controlador = new EmpleadoControlador();
        EmpleadoVista vista = new EmpleadoVista(controlador);
        vista.mostrarMenu();
    }
}
