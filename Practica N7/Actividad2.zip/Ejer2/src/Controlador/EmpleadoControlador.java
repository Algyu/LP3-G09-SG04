package Controlador;

import Modelo.Empleado;
import java.io.*;
import java.util.*;

public class EmpleadoControlador {
    private final String archivo = "empleados.txt";
    private ArrayList<Empleado> lista = new ArrayList<>();

    public EmpleadoControlador() {
        leerEmpleados();
    }

    public void leerEmpleados() {
        lista.clear();
        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] datos = linea.split(",");
                if (datos.length == 3) {
                    int numero = Integer.parseInt(datos[0]);
                    String nombre = datos[1];
                    double sueldo = Double.parseDouble(datos[2]);
                    lista.add(new Empleado(numero, nombre, sueldo));
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("Archivo no encontrado. Se creará al agregar empleados.");
        } catch (IOException e) {
            System.out.println("Error al leer los datos: " + e.getMessage());
        }
    }

    private void guardarEmpleados() {
        try (PrintWriter pw = new PrintWriter(new FileWriter(archivo))) {
            for (Empleado emp : lista) {
                pw.println(emp.getNumero() + "," + emp.getNombre() + "," + emp.getSueldo());
            }
        } catch (IOException e) {
            System.out.println("Error al guardar datos: " + e.getMessage());
        }
    }

    public void agregarEmpleado(Empleado e) {
        for (Empleado emp : lista) {
            if (emp.getNumero() == e.getNumero()) {
                System.out.println("Ya existe un empleado con ese número.");
                return;
            }
        }
        lista.add(e);
        guardarEmpleados();
        System.out.println("Empleado agregado correctamente.");
    }

    public void listarEmpleados() {
        if (lista.isEmpty()) {
            System.out.println("No hay empleados registrados.");
        } else {
            System.out.println("\n=== LISTA DE EMPLEADOS ===");
            for (Empleado e : lista) {
                System.out.println(e);
            }
        }
    }

    public void buscarEmpleado(int numero) {
        for (Empleado e : lista) {
            if (e.getNumero() == numero) {
                System.out.println("Empleado encontrado:");
                System.out.println(e);
                return;
            }
        }
        System.out.println("No se encontró un empleado con ese número.");
    }

    public void eliminarEmpleado(int numero) {
        boolean eliminado = lista.removeIf(e -> e.getNumero() == numero);
        if (eliminado) {
            guardarEmpleados();
            System.out.println("Empleado eliminado correctamente.");
        } else {
            System.out.println("No se encontró un empleado con ese número.");
        }
    }
}
