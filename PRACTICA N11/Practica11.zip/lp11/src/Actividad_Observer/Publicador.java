package Actividad_Observer;

import java.util.ArrayList;

public class Publicador {
    private ArrayList<Observador> seguidores = new ArrayList<>();
    private String nombre;

    public Publicador(String nombre) {
        this.nombre = nombre;
    }

    public void seguir(Observador o) {
        seguidores.add(o);
        System.out.println(((Usuario)o).getNombre() + " ahora sigue a " + nombre);
    }

    public void dejarDeSeguir(Observador o) {
        seguidores.remove(o);
        System.out.println(((Usuario)o).getNombre() + " dejó de seguir a " + nombre);
    }

    public void publicar(String contenido) {
        System.out.println("\n" + nombre + " ha publicado: " + contenido);
        notificarSeguidores("Nueva publicación de " + nombre + ": " + contenido);
    }

    private void notificarSeguidores(String msg) {
        for (Observador o : seguidores) {
            o.recibirNotificacion(msg);
        }
    }
}

