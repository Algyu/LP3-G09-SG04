package Actividad_Observer;

public interface Observador {
    void recibirNotificacion(String mensaje);
}