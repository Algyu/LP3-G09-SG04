package Actividad_Observer;

public class MainObserver {
    public static void main(String[] args) {

        Publicador maria = new Publicador("MariaIG");

        Usuario juan = new Usuario("Juan");
        Usuario pedro = new Usuario("Pedro");
        Usuario luisa = new Usuario("Luisa");

        maria.seguir(juan);
        maria.seguir(pedro);
        maria.seguir(luisa);

        maria.publicar("Nuevo post: Café en el centro");

        maria.dejarDeSeguir(pedro);

        maria.publicar("Nuevo post: Paseo nocturno");
    }
}