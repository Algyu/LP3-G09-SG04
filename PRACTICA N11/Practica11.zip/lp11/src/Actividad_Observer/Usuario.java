package Actividad_Observer;

public class Usuario implements Observador {
    private String nombre;

    public Usuario(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public void recibirNotificacion(String mensaje) {
        System.out.println(nombre + " recibió la notificación: " + mensaje);
    }

    public String getNombre() {
        return nombre;
    }
}
