package Act2_Observer;

public interface Observador {
    void recibirNotificacion(String mensaje);
}
