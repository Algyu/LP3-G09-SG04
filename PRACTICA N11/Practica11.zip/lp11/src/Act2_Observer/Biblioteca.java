package Act2_Observer;

import java.util.ArrayList;

public class Biblioteca {

    private ArrayList<Observador> usuarios = new ArrayList<>();

    public void registrarUsuario(Observador o) {
        usuarios.add(o);
    }

    public void notificar(String mensaje) {
        for (Observador u : usuarios) {
            u.recibirNotificacion(mensaje);
        }
    }

    public void agregarLibro(String titulo) {
        System.out.println("Nuevo libro agregado: " + titulo);
        notificar("Se agregó un nuevo libro: " + titulo);
    }

    public void libroDisponible(String titulo) {
        notificar("El libro '" + titulo + "' ya está disponible.");
    }
}