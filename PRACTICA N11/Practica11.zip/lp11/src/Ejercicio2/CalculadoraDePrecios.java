package Ejercicio2;

public class CalculadoraDePrecios {

    private EstrategiaDescuento estrategia;

    public void setEstrategia(EstrategiaDescuento estrategia) {
        this.estrategia = estrategia;
    }

    public double calcularTotal(Producto[] productos) {
        return estrategia.aplicarDescuento(productos);
    }
}

