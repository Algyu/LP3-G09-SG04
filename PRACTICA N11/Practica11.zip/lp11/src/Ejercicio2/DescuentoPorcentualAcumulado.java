package Ejercicio2;

public class DescuentoPorcentualAcumulado implements EstrategiaDescuento {

    @Override
    public double aplicarDescuento(Producto[] productos) {

        if (productos.length >= 3) {

            double total = 0;
            double menor = productos[0].getPrecio();

            for (Producto p : productos) {
                total += p.getPrecio();
                if (p.getPrecio() < menor) {
                    menor = p.getPrecio();
                }
            }

            total -= menor * 0.50;
            return total;
        }

        double total = 0;
        for (Producto p : productos) {
            total += p.getPrecio();
        }
        return total;
    }
}
