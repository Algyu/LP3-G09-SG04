package Ejercicio2;

public class DescuentoPorcentual implements EstrategiaDescuento {

    @Override
    public double aplicarDescuento(Producto[] productos) {
        if (productos.length == 2 &&
            productos[0].getNombre().equals(productos[1].getNombre())) {

            double total = productos[0].getPrecio() + productos[1].getPrecio();
            return total * 0.70; 
        }

        double total = 0;
        for (Producto p : productos) {
            total += p.getPrecio();
        }
        return total;
    }
}

