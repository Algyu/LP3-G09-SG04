package Ejercicio2;

import java.util.Scanner;

public class MainStrategy {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        Producto choco1 = new Producto("Chocolate Blanco", 5.0);
        Producto choco2 = new Producto("Chocolate Negro", 6.0);
        Producto choco3 = new Producto("Chocolate con Almendras", 7.0);

        System.out.println("TIENDA DE CHOCOLATES");
        System.out.println("1. Chocolate Blanco - 5");
        System.out.println("2. Chocolate Negro - 6");
        System.out.println("3. Chocolate con Almendras - 7");
        System.out.println("Cuantos productos va a comprar?");
        int cantidad = sc.nextInt();

        Producto[] carrito = new Producto[cantidad];

        for (int i = 0; i < cantidad; i++) {
            System.out.println("Seleccione producto " + (i + 1) + ": ");
            int op = sc.nextInt();

            switch (op) {
                case 1: carrito[i] = choco1; break;
                case 2: carrito[i] = choco2; break;
                case 3: carrito[i] = choco3; break;
                default:
                    System.out.println("Producto invalido, se asigna Chocolate Blanco");
                    carrito[i] = choco1;
            }
        }

        System.out.println("\nSeleccione tipo de descuento:");
        System.out.println("1. Sin Descuento");
        System.out.println("2. Descuento Fijo (10%)");
        System.out.println("3. Descuento Porcentual (2 iguales 30%)");
        System.out.println("4. Descuento Porcentual Acumulado (3 o mas, 50% al mas barato)");

        int desc = sc.nextInt();

        CalculadoraDePrecios calc = new CalculadoraDePrecios();

        switch (desc) {
            case 1: calc.setEstrategia(new SinDescuento()); break;
            case 2: calc.setEstrategia(new DescuentoFijo()); break;
            case 3: calc.setEstrategia(new DescuentoPorcentual()); break;
            case 4: calc.setEstrategia(new DescuentoPorcentualAcumulado()); break;
            default:
                System.out.println("Opcion invalida, usando Sin Descuento");
                calc.setEstrategia(new SinDescuento());
        }

        double total = calc.calcularTotal(carrito);

        System.out.println("\nTotal a pagar: " + total);
    }
}
