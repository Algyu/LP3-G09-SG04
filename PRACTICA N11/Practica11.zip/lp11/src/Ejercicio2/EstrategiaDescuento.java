package Ejercicio2;

public interface EstrategiaDescuento {
    double aplicarDescuento(Producto[] productos);
}
