package Ejercicio2;

public class SinDescuento implements EstrategiaDescuento {

    @Override
    public double aplicarDescuento(Producto[] productos) {
        double total = 0;
        for (Producto p : productos) {
            total += p.getPrecio();
        }
        return total;
    }
}

