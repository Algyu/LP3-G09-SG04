package Main;

import Act2_Command.Comando;
import Act2_Command.FavoritoCommand;
import Act2_Command.Libro;
import Act2_Command.PedirLibro;
import Act2_Command.ReservarLibro;
import Act2_Observer.Biblioteca;
import Act2_Observer.Usuario;
import Act2_Strategy.CalculadoraTarifa;
import Act2_Strategy.TarifaEstudiante;
import Act2_Strategy.TarifaNormal;

public class Main {
    public static void main(String[] args) {

        // OBSERVER
        Biblioteca biblioteca = new Biblioteca();
        Usuario ana = new Usuario("Ana");
        Usuario jose = new Usuario("José");

        biblioteca.registrarUsuario(ana);
        biblioteca.registrarUsuario(jose);

        biblioteca.agregarLibro("El Principito");


        // STRATEGY
        CalculadoraTarifa calc = new CalculadoraTarifa();
        double base = 10;

        calc.setEstrategia(new TarifaEstudiante());
        System.out.println("Tarifa estudiante: " + calc.calcular(base));

        calc.setEstrategia(new TarifaNormal());
        System.out.println("Tarifa normal: " + calc.calcular(base));


        // COMMAND
        Libro libro = new Libro("El Principito");

        Comando pedir = new PedirLibro(libro);
        Comando reservar = new ReservarLibro(libro);
        Comando favorito = new FavoritoCommand(libro);

        pedir.ejecutar();
        reservar.ejecutar();
        favorito.ejecutar();
    }
}

