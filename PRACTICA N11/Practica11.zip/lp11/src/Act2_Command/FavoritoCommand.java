package Act2_Command;

public class FavoritoCommand implements Comando {

    private Libro libro;

    public FavoritoCommand(Libro libro) {
        this.libro = libro;
    }

    @Override
    public void ejecutar() {
        System.out.println("Libro marcado como favorito: " + libro.getTitulo());
    }
}

