package Act2_Command;

public class CancelarReserva implements Comando {

    private Libro libro;

    public CancelarReserva(Libro libro) {
        this.libro = libro;
    }

    @Override
    public void ejecutar() {
        System.out.println("Reserva cancelada del libro: " + libro.getTitulo());
    }
}

