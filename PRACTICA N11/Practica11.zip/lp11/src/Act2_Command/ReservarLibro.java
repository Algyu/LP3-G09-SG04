package Act2_Command;

public class ReservarLibro implements Comando {

    private Libro libro;

    public ReservarLibro(Libro libro) {
        this.libro = libro;
    }

    @Override
    public void ejecutar() {
        System.out.println("Libro reservado: " + libro.getTitulo());
    }
}

