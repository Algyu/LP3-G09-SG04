package Act2_Command;

public class PedirLibro implements Comando {

    private Libro libro;

    public PedirLibro(Libro libro) {
        this.libro = libro;
    }

    @Override
    public void ejecutar() {
        System.out.println("Se pidió el libro: " + libro.getTitulo());
    }
}
