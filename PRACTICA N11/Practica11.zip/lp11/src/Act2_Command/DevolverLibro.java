package Act2_Command;

public class DevolverLibro implements Comando {

    private Libro libro;

    public DevolverLibro(Libro libro) {
        this.libro = libro;
    }

    @Override
    public void ejecutar() {
        System.out.println("Se devolvió el libro: " + libro.getTitulo());
    }
}

