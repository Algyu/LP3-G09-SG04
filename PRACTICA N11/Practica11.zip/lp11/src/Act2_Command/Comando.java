package Act2_Command;

public interface Comando {
    void ejecutar();
}

