package Eje3Strategy;

public interface EstrategiaDescuento {
    double aplicarDescuento(Entrada[] entradas);
}
