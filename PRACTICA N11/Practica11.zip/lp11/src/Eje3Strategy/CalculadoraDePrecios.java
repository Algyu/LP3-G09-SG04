package Eje3Strategy;

public class CalculadoraDePrecios {

    private EstrategiaDescuento estrategia;

    public void setEstrategia(EstrategiaDescuento estrategia) {
        this.estrategia = estrategia;
    }

    public double calcular(Entrada[] entradas) {
        return estrategia.aplicarDescuento(entradas);
    }
}
