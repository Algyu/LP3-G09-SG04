package Eje3Strategy;

public class SinDescuento implements EstrategiaDescuento {

    @Override
    public double aplicarDescuento(Entrada[] entradas) {
        double total = 0;
        for (Entrada e : entradas) {
            total += e.getPrecio();
        }
        return total;
    }
}
