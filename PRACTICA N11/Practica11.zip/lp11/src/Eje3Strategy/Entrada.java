package Eje3Strategy;

public class Entrada {

    private String tipo;
    private double precio;

    public Entrada(String tipo, double precio) {
        this.tipo = tipo;
        this.precio = precio;
    }

    public String getTipo() {
        return tipo;
    }

    public double getPrecio() {
        return precio;
    }
}

