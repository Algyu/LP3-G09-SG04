package Eje3Strategy;

public class DescuentoFijo implements EstrategiaDescuento {

    @Override
    public double aplicarDescuento(Entrada[] entradas) {
        double total = 0;
        for (Entrada e : entradas) {
            total += e.getPrecio();
        }
        return total * 0.90;
    }
}

