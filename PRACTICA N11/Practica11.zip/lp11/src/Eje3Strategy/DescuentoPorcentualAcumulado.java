package Eje3Strategy;

public class DescuentoPorcentualAcumulado implements EstrategiaDescuento {

    @Override
    public double aplicarDescuento(Entrada[] entradas) {

        if (entradas.length >= 3) {
            double total = 0;
            double menor = entradas[0].getPrecio();

            for (Entrada e : entradas) {
                total += e.getPrecio();
                if (e.getPrecio() < menor) {
                    menor = e.getPrecio();
                }
            }

            total -= menor * 0.50;
            return total;
        }

        double total = 0;
        for (Entrada e : entradas) {
            total += e.getPrecio();
        }
        return total;
    }
}