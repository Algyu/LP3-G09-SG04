package Eje3Strategy;

public class DescuentoPorcentual implements EstrategiaDescuento {

    @Override
    public double aplicarDescuento(Entrada[] entradas) {

        if (entradas.length == 2 &&
            entradas[0].getTipo().equals(entradas[1].getTipo())) {

            double total = entradas[0].getPrecio() + entradas[1].getPrecio();
            return total * 0.70;
        }

        double total = 0;
        for (Entrada e : entradas) {
            total += e.getPrecio();
        }
        return total;
    }
}

