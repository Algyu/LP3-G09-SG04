package Eje3Observer;

public interface Observador {
    void recibirNotificacion(Notificacion noti);
}