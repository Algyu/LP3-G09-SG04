package Eje3Observer;

import java.util.ArrayList;

public class SistemaCine {

    private ArrayList<Observador> usuarios = new ArrayList<>();

    public void suscribir(Observador o) {
        usuarios.add(o);
        System.out.println("Usuario suscrito");
    }

    public void desuscribir(Observador o) {
        usuarios.remove(o);
        System.out.println("Usuario desuscrito");
    }

    public void enviarNotificacion(String mensaje) {
        Notificacion noti = new Notificacion(mensaje);
        for (Observador u : usuarios) {
            u.recibirNotificacion(noti);
        }
    }
}

