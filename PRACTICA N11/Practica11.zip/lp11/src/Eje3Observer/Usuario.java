package Eje3Observer;

public class Usuario implements Observador {

    private String nombre;

    public Usuario(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public void recibirNotificacion(Notificacion noti) {
        System.out.println(nombre + " recibio notificacion: " + noti.getMensaje());
    }
}

