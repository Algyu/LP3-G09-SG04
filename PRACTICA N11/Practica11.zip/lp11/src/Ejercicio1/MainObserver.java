package Ejercicio1;

public class MainObserver {
    public static void main(String[] args) {

        SubjectSistemaClima clima = new SubjectSistemaClima();

        Usuario ana = new Usuario("Ana");
        Usuario pedro = new Usuario("Pedro");
        Usuario lucia = new Usuario("Lucia");

        clima.suscribir(ana);
        clima.suscribir(pedro);
        clima.suscribir(lucia);

        clima.enviarAlerta("Alerta de lluvia fuerte");
        clima.enviarAlerta("Temperatura baja en la ciudad");

        clima.desuscribir(pedro);

        clima.enviarAlerta("Viento fuerte en la zona norte");
    }
}

