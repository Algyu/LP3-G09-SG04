package Ejercicio1;

import java.util.ArrayList;

public class SubjectSistemaClima {

    private ArrayList<Observador> usuarios = new ArrayList<>();

    public void suscribir(Observador usuario) {
        usuarios.add(usuario);
        System.out.println("Usuario suscrito.");
    }

    public void desuscribir(Observador usuario) {
        usuarios.remove(usuario);
        System.out.println("Usuario desuscrito.");
    }

    public void enviarAlerta(String mensaje) {
        Notificacion noti = new Notificacion(mensaje);
        notificarUsuarios(noti);
    }

    private void notificarUsuarios(Notificacion noti) {
        for (Observador u : usuarios) {
            u.recibirNotificacion(noti);
        }
    }
}

