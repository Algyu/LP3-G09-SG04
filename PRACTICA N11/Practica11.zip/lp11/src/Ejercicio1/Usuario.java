package Ejercicio1;

public class Usuario implements Observador {

    private String nombre;

    public Usuario(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public void recibirNotificacion(Notificacion notificacion) {
        System.out.println(nombre + " recibio notificacion: " + notificacion.getMensaje());
    }

    public String getNombre() {
        return nombre;
    }
}

