package Ejercicio1;

public interface Observador {
    void recibirNotificacion(Notificacion notificacion);
}
