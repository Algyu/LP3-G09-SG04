package Actividad_Strategy;

public class CalculadoraPrecios {

    private EstrategiaPromocion estrategia;

    public void setEstrategia(EstrategiaPromocion estrategia) {
        this.estrategia = estrategia;
    }

    public double calcular(Producto p) {
        return estrategia.aplicarPromocion(p.getPrecio());
    }
}

