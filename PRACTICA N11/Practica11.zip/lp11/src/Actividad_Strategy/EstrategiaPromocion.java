package Actividad_Strategy;

public interface EstrategiaPromocion {
    double aplicarPromocion(double precio);
}

