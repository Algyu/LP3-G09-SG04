package Actividad_Strategy;

public class PromocionEspecial implements EstrategiaPromocion {
    @Override
    public double aplicarPromocion(double precio) {
        return precio * 0.80;
    }
}

