package Actividad_Strategy;

public class SinPromocion implements EstrategiaPromocion {
    @Override
    public double aplicarPromocion(double precio) {
        return precio;
    }
}

