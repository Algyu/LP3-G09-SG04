package Actividad_Strategy;

import java.util.Scanner;

public class MainStrategy {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        Producto p = new Producto("Cámara Profesional", 1200);

        CalculadoraPrecios calc = new CalculadoraPrecios();

        System.out.println("PROMOCIONES DISPONIBLES");
        System.out.println("1. Sin Promoción");
        System.out.println("2. Promoción 10%");
        System.out.println("3. Promoción Especial 20%");
        System.out.print("Seleccione una opción: ");
        int opcion = sc.nextInt();

        switch (opcion) {
            case 1: calc.setEstrategia(new SinPromocion()); break;
            case 2: calc.setEstrategia(new PromocionDiezPorciento()); break;
            case 3: calc.setEstrategia(new PromocionEspecial()); break;
            default:
                System.out.println("Opción invalida, usando Sin Promocion");
                calc.setEstrategia(new SinPromocion());
        }

        double precioFinal = calc.calcular(p);

        System.out.println("Producto: " + p.getNombre());
        System.out.println("Precio original: $" + p.getPrecio());
        System.out.println("Precio final: $" + precioFinal);
    }
}

