package Actividad_Strategy;

public class PromocionDiezPorciento implements EstrategiaPromocion {
    @Override
    public double aplicarPromocion(double precio) {
        return precio * 0.90;
    }
}

