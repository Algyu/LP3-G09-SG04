package Act2_Strategy;

public interface EstrategiaTarifa {
    double calcularTarifa(double base);
}
