package Act2_Strategy;

public class CalculadoraTarifa {

    private EstrategiaTarifa estrategia;

    public void setEstrategia(EstrategiaTarifa estrategia) {
        this.estrategia = estrategia;
    }

    public double calcular(double base) {
        return estrategia.calcularTarifa(base);
    }
}

