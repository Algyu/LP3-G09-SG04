package Act2_Strategy;

public class TarifaEstudiante implements EstrategiaTarifa {
    @Override
    public double calcularTarifa(double base) {
        return base * 0.80;
    }
}
