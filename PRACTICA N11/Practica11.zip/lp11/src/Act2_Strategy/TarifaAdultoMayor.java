package Act2_Strategy;

public class TarifaAdultoMayor implements EstrategiaTarifa {
    @Override
    public double calcularTarifa(double base) {
        return base * 0.70;
    }
}

