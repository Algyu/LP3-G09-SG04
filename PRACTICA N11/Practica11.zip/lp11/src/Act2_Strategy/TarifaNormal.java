package Act2_Strategy;

public class TarifaNormal implements EstrategiaTarifa {
    @Override
    public double calcularTarifa(double base) {
        return base;
    }
}
