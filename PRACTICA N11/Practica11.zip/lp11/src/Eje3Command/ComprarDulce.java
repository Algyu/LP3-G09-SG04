package Eje3Command;

public class ComprarDulce implements Comando {

    private CarritoCine carrito;

    public ComprarDulce(CarritoCine carrito) {
        this.carrito = carrito;
    }

    @Override
    public void ejecutar() {
        carrito.agregarAccion("Se compro un dulce");
    }
}

