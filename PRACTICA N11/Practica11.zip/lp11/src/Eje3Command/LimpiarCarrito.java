package Eje3Command;

public class LimpiarCarrito implements Comando {

    private CarritoCine carrito;

    public LimpiarCarrito(CarritoCine carrito) {
        this.carrito = carrito;
    }

    @Override
    public void ejecutar() {
        carrito.limpiar();
    }
}
