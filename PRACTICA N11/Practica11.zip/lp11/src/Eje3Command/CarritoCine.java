package Eje3Command;

import java.util.ArrayList;

public class CarritoCine {

    private ArrayList<String> acciones = new ArrayList<>();

    public void agregarAccion(String accion) {
        acciones.add(accion);
        System.out.println("Accion ejecutada: " + accion);
    }

    public void mostrarAcciones() {
        System.out.println("Resumen de acciones:");
        for (String a : acciones) {
            System.out.println("- " + a);
        }
    }

    public void limpiar() {
        acciones.clear();
        System.out.println("Carrito limpiado");
    }
}
