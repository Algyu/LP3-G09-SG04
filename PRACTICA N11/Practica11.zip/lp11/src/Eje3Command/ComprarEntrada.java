package Eje3Command;

public class ComprarEntrada implements Comando {

    private CarritoCine carrito;

    public ComprarEntrada(CarritoCine carrito) {
        this.carrito = carrito;
    }

    @Override
    public void ejecutar() {
        carrito.agregarAccion("Se compro una entrada");
    }
}
