package Eje3Command;

public class MostrarResumen implements Comando {

    private CarritoCine carrito;

    public MostrarResumen(CarritoCine carrito) {
        this.carrito = carrito;
    }

    @Override
    public void ejecutar() {
        carrito.mostrarAcciones();
    }
}

