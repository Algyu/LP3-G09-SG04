package Eje3Command;

public class CancelarCompra implements Comando {

    private CarritoCine carrito;

    public CancelarCompra(CarritoCine carrito) {
        this.carrito = carrito;
    }

    @Override
    public void ejecutar() {
        carrito.agregarAccion("Se cancelo la compra");
    }
}

