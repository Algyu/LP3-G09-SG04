package Eje3Command;

public interface Comando {
    void ejecutar();
}
