package Actividad_Command;

public class Televisor {
    private boolean encendido = false;
    private int volumen = 10;
    private int hdmi = 1;

    public void encender() {
        encendido = true;
        System.out.println("Televisor encendido.");
    }

    public void apagar() {
        encendido = false;
        System.out.println("Televisor apagado.");
    }

    public void subirVolumen() {
        if (volumen < 100) volumen++;
        System.out.println("Volumen actual: " + volumen);
    }

    public void bajarVolumen() {
        if (volumen > 0) volumen--;
        System.out.println("Volumen actual: " + volumen);
    }

    public void cambiarHDMI() {
        hdmi++;
        if (hdmi > 3) hdmi = 1;
        System.out.println("HDMI cambiado a: " + hdmi);
    }
}

