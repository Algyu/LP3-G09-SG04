package Actividad_Command;

public interface Comando {
    void ejecutar();
}
