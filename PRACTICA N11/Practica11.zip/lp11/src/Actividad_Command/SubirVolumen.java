package Actividad_Command;

public class SubirVolumen implements Comando {
    private Televisor tv;

    public SubirVolumen(Televisor tv) { this.tv = tv; }

    @Override
    public void ejecutar() {
        tv.subirVolumen();
    }
}

