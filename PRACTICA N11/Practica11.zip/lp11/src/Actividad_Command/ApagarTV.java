package Actividad_Command;

public class ApagarTV implements Comando {
    private Televisor tv;

    public ApagarTV(Televisor tv) { this.tv = tv; }

    @Override
    public void ejecutar() {
        tv.apagar();
    }
}

