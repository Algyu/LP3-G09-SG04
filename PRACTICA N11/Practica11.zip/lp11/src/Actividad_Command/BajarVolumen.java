package Actividad_Command;

public class BajarVolumen implements Comando {
    private Televisor tv;

    public BajarVolumen(Televisor tv) { this.tv = tv; }

    @Override
    public void ejecutar() {
        tv.bajarVolumen();
    }
}

