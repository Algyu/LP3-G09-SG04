package Actividad_Command;

public class EncenderTV implements Comando {
    private Televisor tv;

    public EncenderTV(Televisor tv) { this.tv = tv; }

    @Override
    public void ejecutar() {
        tv.encender();
    }
}

