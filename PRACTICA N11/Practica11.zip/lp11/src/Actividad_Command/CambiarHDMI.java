package Actividad_Command;

public class CambiarHDMI implements Comando {
    private Televisor tv;

    public CambiarHDMI(Televisor tv) { this.tv = tv; }

    @Override
    public void ejecutar() {
        tv.cambiarHDMI();
    }
}

