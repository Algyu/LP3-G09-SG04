package Actividad_Command;

public class MainCommand {
    public static void main(String[] args) {

        Televisor tv = new Televisor();
        ControlRemoto control = new ControlRemoto();

        control.setComando(new EncenderTV(tv));
        control.presionarBoton();

        control.setComando(new SubirVolumen(tv));
        control.presionarBoton();

        control.setComando(new SubirVolumen(tv));
        control.presionarBoton();

        control.setComando(new BajarVolumen(tv));
        control.presionarBoton();

        control.setComando(new CambiarHDMI(tv));
        control.presionarBoton();

        control.setComando(new ApagarTV(tv));
        control.presionarBoton();
    }
}

