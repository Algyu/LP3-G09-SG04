package Ejer3Main;

import java.util.Scanner;

import Eje3Observer.Usuario;
import Eje3Observer.SistemaCine;

import Eje3Strategy.Entrada;
import Eje3Strategy.CalculadoraDePrecios;
import Eje3Strategy.SinDescuento;
import Eje3Strategy.DescuentoFijo;
import Eje3Strategy.DescuentoPorcentual;
import Eje3Strategy.DescuentoPorcentualAcumulado;

import Eje3Command.CarritoCine;
import Eje3Command.Comando;
import Eje3Command.ComprarEntrada;
import Eje3Command.ComprarDulce;
import Eje3Command.CancelarCompra;
import Eje3Command.MostrarResumen;
import Eje3Command.LimpiarCarrito;

public class MainCine {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // OBSERVER
        SistemaCine cine = new SistemaCine();
        Usuario ana = new Usuario("Ana");
        Usuario pedro = new Usuario("Pedro");

        cine.suscribir(ana);
        cine.suscribir(pedro);

        cine.enviarNotificacion("Nuevo estreno: Avengers");
        cine.enviarNotificacion("Promo en combos de dulces");


        // STRATEGY
        Entrada normal = new Entrada("Normal", 15);
        Entrada vip = new Entrada("VIP", 25);

        System.out.println("\nCuantas entradas desea comprar?");
        int n = sc.nextInt();

        Entrada[] carritoEntradas = new Entrada[n];

        for (int i = 0; i < n; i++) {
            System.out.println("Seleccione tipo de entrada (1.Normal, 2.VIP): ");
            int op = sc.nextInt();
            carritoEntradas[i] = (op == 2) ? vip : normal;
        }

        System.out.println("\nSeleccione descuento:");
        System.out.println("1. Sin descuento");
        System.out.println("2. Descuento fijo 10%");
        System.out.println("3. Dos iguales 30%");
        System.out.println("4. Tres o mas 50% en la mas barata");

        int d = sc.nextInt();

        CalculadoraDePrecios calc = new CalculadoraDePrecios();

        switch (d) {
            case 1: calc.setEstrategia(new SinDescuento()); break;
            case 2: calc.setEstrategia(new DescuentoFijo()); break;
            case 3: calc.setEstrategia(new DescuentoPorcentual()); break;
            case 4: calc.setEstrategia(new DescuentoPorcentualAcumulado()); break;
            default: calc.setEstrategia(new SinDescuento());
        }

        double total = calc.calcular(carritoEntradas);
        System.out.println("Total a pagar: " + total);


        // COMMAND
        CarritoCine carrito = new CarritoCine();

        Comando comprarEntrada = new ComprarEntrada(carrito);
        Comando comprarDulce = new ComprarDulce(carrito);
        Comando cancelar = new CancelarCompra(carrito);
        Comando mostrar = new MostrarResumen(carrito);
        Comando limpiar = new LimpiarCarrito(carrito);

        System.out.println("\nAcciones en el cine:");
        comprarEntrada.ejecutar();
        comprarDulce.ejecutar();
        mostrar.ejecutar();
        cancelar.ejecutar();
        limpiar.ejecutar();
    }
}

