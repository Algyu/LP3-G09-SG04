package FastBite.Strategy;

public class PromoSinDescuento implements Promocion {

    @Override
    public double calcularPrecio(double precioBase) {
        return precioBase;
    }
}