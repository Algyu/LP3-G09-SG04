package FastBite.Strategy;

public class CajaFastBite {

    private Promocion promo;

    public void setPromocion(Promocion promo) {
        this.promo = promo;
    }

    public double procesarPedido(double precioBase) {

        if(promo == null){
            return precioBase;
        }

        return promo.calcularPrecio(precioBase);
    }
}
