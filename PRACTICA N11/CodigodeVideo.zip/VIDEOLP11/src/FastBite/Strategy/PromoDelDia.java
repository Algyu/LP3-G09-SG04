package FastBite.Strategy;

public class PromoDelDia implements Promocion {

    @Override
    public double calcularPrecio(double precioBase) {
        return 12.50;
    }
}