package FastBite.Strategy;

public class PromoClienteFrecuente implements Promocion {

    @Override
    public double calcularPrecio(double precioBase) {
        return precioBase * 0.85;
    }
}