package FastBite.Strategy;

public interface Promocion {
    double calcularPrecio(double precioBase);
}