package FastBite.Strategy;

public class MainStrategy {

    public static void main(String[] args) {

        CajaFastBite caja = new CajaFastBite();

        double precioHamburguesa = 20.0;

        caja.setPromocion(new PromoSinDescuento());
        System.out.println("Sin descuento: " + caja.procesarPedido(precioHamburguesa));

        caja.setPromocion(new Promo10PorCiento());
        System.out.println("Promo 10%: " + caja.procesarPedido(precioHamburguesa));

        caja.setPromocion(new PromoClienteFrecuente());
        System.out.println("Cliente frecuente: " + caja.procesarPedido(precioHamburguesa));

        caja.setPromocion(new PromoDelDia());
        System.out.println("Promo del día: " + caja.procesarPedido(precioHamburguesa));
    }
}

