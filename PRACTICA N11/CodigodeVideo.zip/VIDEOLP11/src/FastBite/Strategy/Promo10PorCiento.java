package FastBite.Strategy;

public class Promo10PorCiento implements Promocion {

    @Override
    public double calcularPrecio(double precioBase) {
        return precioBase * 0.90;
    }
}