package FastBite.Command;

public class ComandoBoleta implements Comando {

    private Cocina cocina;

    public ComandoBoleta(Cocina cocina) {
        this.cocina = cocina;
    }

    @Override
    public void ejecutar() {
        cocina.imprimirBoleta();
    }
}