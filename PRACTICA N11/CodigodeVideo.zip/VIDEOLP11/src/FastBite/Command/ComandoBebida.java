package FastBite.Command;

public class ComandoBebida implements Comando {

    private Cocina cocina;

    public ComandoBebida(Cocina cocina) {
        this.cocina = cocina;
    }

    @Override
    public void ejecutar() {
        cocina.prepararBebida();
    }
}