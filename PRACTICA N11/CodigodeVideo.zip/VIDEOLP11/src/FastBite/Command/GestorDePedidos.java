package FastBite.Command;

import java.util.ArrayList;
import java.util.List;

public class GestorDePedidos {

    private List<Comando> cola = new ArrayList<>();

    public void agregarComando(Comando c){
        cola.add(c);
    }

    public void procesar(){
        for(Comando c : cola){
            c.ejecutar();
        }
        cola.clear();
    }
}

