package FastBite.Command;

public class ComandoHamburguesa implements Comando {

    private Cocina cocina;

    public ComandoHamburguesa(Cocina cocina) {
        this.cocina = cocina;
    }

    @Override
    public void ejecutar() {
        cocina.prepararHamburguesa();
    }
}