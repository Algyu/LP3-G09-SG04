package FastBite.Command;

public interface Comando {
    void ejecutar();
}