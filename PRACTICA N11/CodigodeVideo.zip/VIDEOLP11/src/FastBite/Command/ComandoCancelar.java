package FastBite.Command;

public class ComandoCancelar implements Comando {

    private Cocina cocina;

    public ComandoCancelar(Cocina cocina) {
        this.cocina = cocina;
    }

    @Override
    public void ejecutar() {
        cocina.cancelarPedido();
    }
}

