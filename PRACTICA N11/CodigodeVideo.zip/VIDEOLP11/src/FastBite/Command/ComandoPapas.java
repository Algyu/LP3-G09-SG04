package FastBite.Command;

public class ComandoPapas implements Comando {

    private Cocina cocina;

    public ComandoPapas(Cocina cocina) {
        this.cocina = cocina;
    }

    @Override
    public void ejecutar() {
        cocina.prepararPapas();
    }
}