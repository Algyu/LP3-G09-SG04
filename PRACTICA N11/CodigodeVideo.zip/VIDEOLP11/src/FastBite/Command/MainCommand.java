package FastBite.Command;

public class MainCommand {

    public static void main(String[] args) {

        Cocina cocina = new Cocina();
        GestorDePedidos gestor = new GestorDePedidos();

        gestor.agregarComando(new ComandoHamburguesa(cocina));
        gestor.agregarComando(new ComandoPapas(cocina));
        gestor.agregarComando(new ComandoBebida(cocina));
        gestor.agregarComando(new ComandoBoleta(cocina));

        gestor.procesar();
    }
}