package FastBite.Command;

public class Cocina {

    public void prepararHamburguesa() {
        System.out.println("Preparando hamburguesa...");
    }

    public void prepararPapas() {
        System.out.println("Fritando papas...");
    }

    public void prepararBebida() {
        System.out.println("Sirviendo bebida...");
    }

    public void cancelarPedido() {
        System.out.println("Pedido cancelado.");
    }

    public void imprimirBoleta() {
        System.out.println("Boleta impresa.");
    }
}
