package Experiencia1;

public class MainExp2 {
    public static void main(String[] args) {
        try {
            CuentaBancaria c1 = new CuentaBancaria("001", "Ana", 100);
            CuentaBancaria c2 = new CuentaBancaria("002", "Luis", 50);

            c1.retirar(30);
            c2.depositar(30);

            if (c2 == null) throw new CuentaNoEncontradaException("Cuenta no existe");

            if (c1.getSaldo() != 0) {
                throw new SaldoNoCeroException("No se puede cerrar la cuenta con saldo diferente de cero");
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
