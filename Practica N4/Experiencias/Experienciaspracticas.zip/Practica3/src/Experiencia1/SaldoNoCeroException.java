package Experiencia1;

public class SaldoNoCeroException extends Exception {
    public SaldoNoCeroException(String msg) {
        super(msg);
    }
}

