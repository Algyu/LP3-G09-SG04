package Experiencia1;

public class MainExp1 {
    public static void main(String[] args) {
        try {
            CuentaBancaria c1 = new CuentaBancaria("001", "Ana", 100);
            c1.depositar(50);
            c1.retirar(200);
        } catch (IllegalArgumentException e) {
            System.out.println("Error de datos: " + e.getMessage());
        } catch (SaldoInsuficienteException e) {
            System.out.println("Error de operación: " + e.getMessage());
        }
    }
}

