package Experiencia1;

public class CuentaNoEncontradaException extends Exception {
    public CuentaNoEncontradaException(String msg) {
        super(msg);
    }
}

