package Experiencia1;

public class LimiteCreditoExcedidoException extends SaldoInsuficienteException {
    public LimiteCreditoExcedidoException(String msg) {
        super(msg);
    }
}

