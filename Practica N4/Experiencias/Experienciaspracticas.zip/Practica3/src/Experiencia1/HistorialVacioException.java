package Experiencia1;

public class HistorialVacioException extends Exception {
    public HistorialVacioException(String msg) {
        super(msg);
    }
}

