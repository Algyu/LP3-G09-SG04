package Experiencia1;

public class MainExp3 {
    public static void main(String[] args) {
        try {
            CuentaCredito cc = new CuentaCredito("003", "Maria", 100, 200);
            cc.retirar(350);
        } catch (LimiteCreditoExcedidoException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
