package Experiencia1;

import java.io.*;
import java.util.*;

public class ReporteTransacciones {
    public void generar(String archivo, List<String> transacciones) throws HistorialVacioException {
        if (transacciones.isEmpty()) {
            throw new HistorialVacioException("No hay transacciones para generar el reporte");
        }
        try (PrintWriter pw = new PrintWriter(new FileWriter(archivo))) {
            for (String t : transacciones) {
                pw.println(t);
            }
        } catch (IOException e) {
            System.out.println("Error al escribir archivo: " + e.getMessage());
        }
    }

    public void leer(String archivo) {
        try (Scanner sc = new Scanner(new File(archivo))) {
            while (sc.hasNextLine()) {
                System.out.println(sc.nextLine());
            }
        } catch (FileNotFoundException e) {
            System.out.println("Archivo no encontrado");
        }
    }
}

