package Experiencia1; 

public class CuentaCredito extends CuentaBancaria {
    private double limiteCredito;

    public CuentaCredito(String numero, String titular, double saldo, double limite) {
        super(numero, titular, saldo);
        this.limiteCredito = limite;
    }

    @Override
    public void retirar(double monto) throws LimiteCreditoExcedidoException {
        double disponible = getSaldo() + limiteCredito;
        if (monto > disponible) {
            throw new LimiteCreditoExcedidoException("Límite de crédito excedido");
        }
    }
}
