package Experiencia1;

import java.util.*;

public class MainExp4 {
    public static void main(String[] args) {
        ReporteTransacciones rep = new ReporteTransacciones();
        List<String> lista = new ArrayList<>();

        try {
            rep.generar("reporte.txt", lista); 
        } catch (HistorialVacioException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}

