package Ejercicio3;

public class Ejercicio3 {
    public static void main(String[] args) {
        try {
            int[] numeros = {1, 2, 3};
            System.out.println("Elemento en posición 5: " + numeros[5]);
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Error: índice fuera de rango -> " + e.getMessage());
        }

        try {
            String texto = null;
            System.out.println(texto.length());
        } catch (NullPointerException e) {
            System.out.println("Error: intento de acceder a un objeto nulo.");
        }

        try {
            int n = Integer.parseInt("abc");
            System.out.println("Número convertido: " + n);
        } catch (NumberFormatException e) {
            System.out.println("Error: formato de número inválido.");
        }
    }
}

