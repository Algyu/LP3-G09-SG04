package Ejercicio1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Ejercicio1 {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Ingrese un carácter (x para salir):");

        char c;
        do {
            c = (char) br.read();
            br.readLine();

            try {
                if (Character.isDigit(c)) {
                    throw new Exception("Se ingresó un número.");
                } else if ("aeiouAEIOU".indexOf(c) != -1) {
                    throw new Exception("Se ingresó una vocal.");
                } else if (c == ' ') {
                    throw new Exception("Se ingresó un espacio.");
                } else if (c != 'x') {
                    System.out.println("Carácter válido: " + c);
                }
            } catch (Exception e) {
                System.out.println("Excepción capturada: " + e.getMessage());
            }

        } while (c != 'x');

        System.out.println("Programa finalizado.");
    }
}
