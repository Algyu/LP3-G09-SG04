package Ejercicio2;

public class Ejercicio2 {
    public static double dividir(double a, double b) throws DivisionPorCeroException {
        if (b == 0) {
            throw new DivisionPorCeroException("No se puede dividir entre cero.");
        }
        return a / b;
    }

    public static void main(String[] args) {
        try {
            double r1 = dividir(10, 2);
            System.out.println("Resultado 10/2 = " + r1);

            double r2 = dividir(10, 0);
            System.out.println("Resultado 10/0 = " + r2);

        } catch (DivisionPorCeroException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
