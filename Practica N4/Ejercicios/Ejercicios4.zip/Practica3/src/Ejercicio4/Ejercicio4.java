package Ejercicio4;

import java.util.ArrayList;
import java.util.NoSuchElementException;

class ListaEstudiantes {
    private ArrayList<String> estudiantes = new ArrayList<>();

    public void agregar(String nombre) {
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre no puede estar vacío.");
        }
        estudiantes.add(nombre);
        System.out.println("Estudiante agregado: " + nombre);
    }

    public void buscar(String nombre) {
        if (!estudiantes.contains(nombre)) {
            throw new NoSuchElementException("No se encontró al estudiante: " + nombre);
        }
        System.out.println("Estudiante encontrado: " + nombre);
    }
}

public class Ejercicio4 {
    public static void main(String[] args) {
        ListaEstudiantes lista = new ListaEstudiantes();

        try {
            lista.agregar("Ana");
            lista.agregar(""); // error
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }

        try {
            lista.buscar("Carlos"); // error
        } catch (NoSuchElementException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}