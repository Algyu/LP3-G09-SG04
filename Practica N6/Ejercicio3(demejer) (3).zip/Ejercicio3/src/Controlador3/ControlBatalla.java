package Controlador3;

import Modelo3.Cazador;
import Modelo3.Demonio;
import Modelo3.Item;
import Vista3.VistaBatalla;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class ControlBatalla {
    private Cazador cazador;
    private List<Demonio> demonios;
    private VistaBatalla vista;

    public ControlBatalla(Cazador cazador, List<Demonio> demonios, VistaBatalla vista) {
        this.cazador = cazador;
        this.demonios = new ArrayList<>(demonios);
        this.vista = vista;
    }

    public void iniciar() {
        Scanner sc = new Scanner(System.in);
        boolean activo = true;

        vista.mostrarInicio(cazador, demonios);

        while (activo && cazador.getSalud() > 0 && !demonios.isEmpty()) {
            vista.mostrarEstado(cazador, demonios);
            vista.mostrarOpciones();
            String opcion = sc.nextLine();

            switch (opcion) {
                case "1":
                    vista.mostrarInventario(cazador.getInventario());
                    int elegido = vista.pedirIndiceObjeto() - 1;
                    if (elegido >= 0 && elegido < cazador.getInventario().size()) {
                        Item elegidoItem = cazador.getInventario().get(elegido);
                        if (!elegidoItem.getTipo().equalsIgnoreCase("Arma")) {
                            vista.mensaje("Debes seleccionar un arma para atacar.");
                            break;
                        }
                        int enem = vista.pedirIndiceEnemigo() - 1;
                        if (enem >= 0 && enem < demonios.size()) {
                            Demonio objetivo = demonios.get(enem);
                            cazador.atacar(objetivo, elegidoItem);
                            vista.mensaje("Atacaste a " + objetivo.getNombre() + " con " + elegidoItem.getNombre() + "!");
                            if (objetivo.getSalud() <= 0) {
                                vista.mensaje(objetivo.getNombre() + " ha sido derrotado.");
                                demonios.remove(objetivo);
                            }
                        } else {
                            vista.mensaje("Enemigo inválido.");
                        }
                    } else {
                        vista.mensaje("Objeto inválido.");
                    }
                    break;

                case "2":
                    vista.mostrarInventario(cazador.getInventario());
                    int pos = vista.pedirIndiceObjeto() - 1;
                    if (pos >= 0 && pos < cazador.getInventario().size()) {
                        Item item = cazador.getInventario().get(pos);
                        if (item.getTipo().equalsIgnoreCase("Poción")) {
                            cazador.usarPocion(item);
                            vista.mensaje(item.usar());
                        } else {
                            vista.mensaje("Ese objeto no es una poción.");
                        }
                    } else {
                        vista.mensaje("Objeto inválido.");
                    }
                    break;

                case "3":
                    vista.mensaje("Decidiste retirarte. El combate termina.");
                    activo = false;
                    break;

                default:
                    vista.mensaje("Opción no reconocida.");
            }

            if (!demonios.isEmpty() && cazador.getSalud() > 0) {
                for (Demonio d : new ArrayList<>(demonios)) {
                    if (d.getSalud() > 0) {
                        d.atacar(cazador);
                        vista.mensaje(d.getNombre() + " contraataca con " + d.getTecnica() + "!");
                        if (cazador.getSalud() <= 0) break;
                    }
                }
            }

            boolean todosMuertos = true;
            for (Demonio d : demonios) if (d.getSalud() > 0) { todosMuertos = false; break; }
            if (todosMuertos && !demonios.isEmpty()) {
                Iterator<Demonio> it = demonios.iterator();
                while (it.hasNext()) {
                    if (it.next().getSalud() <= 0) it.remove();
                }
            }
            if (demonios.isEmpty()) {
                cazador.subirNivel();
                vista.mensaje("Has vencido a todos los demonios. Subes de nivel!");
                activo = false;
            }
        }

        vista.mostrarResultado(cazador, demonios);
    }
}
