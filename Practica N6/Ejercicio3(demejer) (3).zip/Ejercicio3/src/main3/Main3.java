package main3;

import Modelo3.Cazador;
import Modelo3.Demonio;
import Modelo3.Item;
import Vista3.VistaBatalla;
import Controlador3.ControlBatalla;

import java.util.ArrayList;
import java.util.List;

public class Main3 {
    public static void main(String[] args) {
        Cazador cazador = new Cazador("Tanjiro");
        cazador.agregarItem(new Item("Nichirin - Respiración del Agua", "Arma", 18));
        cazador.agregarItem(new Item("Poción Curativa", "Poción", 20));
        cazador.agregarItem(new Item("Nichirin - Respiración del Sol", "Arma", 25));

        List<Demonio> demonios = new ArrayList<>();
        demonios.add(new Demonio("Rui", 2, "Luna Inferior", "Hilos Sangrientos"));
        demonios.add(new Demonio("Daki", 2, "Luna Inferior", "Cintas Sangrientas"));

        VistaBatalla vista = new VistaBatalla();
        ControlBatalla controlador = new ControlBatalla(cazador, demonios, vista);

        controlador.iniciar();
    }
}
