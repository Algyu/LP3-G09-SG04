package Modelo3;

import java.util.ArrayList;
import java.util.List;

public class Cazador {
    private String nombre;
    private int salud;
    private int nivel;
    private List<Item> inventario = new ArrayList<>();

    public Cazador(String nombre) {
        this.nombre = nombre;
        this.salud = 100;
        this.nivel = 1;
    }

    public String getNombre() { return nombre; }
    public int getSalud() { return salud; }
    public int getNivel() { return nivel; }
    public List<Item> getInventario() { return inventario; }

    public void agregarItem(Item item) {
        inventario.add(item);
    }

    public void atacar(Demonio enemigo, Item arma) {
        if (arma == null) return;
        int daño = arma.getPoder() + (nivel * 3);
        enemigo.recibirDaño(daño);
    }

    public boolean usarPocion(Item pocion) {
        if (pocion == null || !pocion.getTipo().equalsIgnoreCase("Poción")) return false;
        salud += pocion.getPoder();
        if (salud > 100) salud = 100;
        inventario.remove(pocion);
        return true;
    }

    public void recibirDaño(int daño) {
        salud -= daño;
        if (salud < 0) salud = 0;
    }

    public void subirNivel() {
        nivel++;
        salud = 100;
    }

    @Override
    public String toString() {
        return nombre + " (Lv." + nivel + ") - Salud: " + salud;
    }
}

