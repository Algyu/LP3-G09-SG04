package Modelo3;

public class Item {
    private String nombre;
    private String tipo;
    private int poder;

    public Item(String nombre, String tipo, int poder) {
        this.nombre = nombre;
        this.tipo = tipo;
        this.poder = poder;
    }

    public String getNombre() { 
        return nombre; 
    }

    public String getTipo() { 
        return tipo; 
    }

    public int getPoder() { 
        return poder; 
    }

    public String usar() {
        if (tipo.equalsIgnoreCase("Poción")) {
            return "Usas " + nombre + " y recuperas " + poder + " puntos de salud.";
        } else if (tipo.equalsIgnoreCase("Arma")) {
            return "Empuñas " + nombre + " (poder " + poder + ").";
        } else {
            return "Usas " + nombre + ".";
        }
    }

    @Override
    public String toString() {
        return nombre + " (" + tipo + ", poder " + poder + ")";
    }
}
