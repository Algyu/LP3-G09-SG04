package Modelo3;

public class Demonio {
    private String nombre;
    private int salud;
    private int nivel;
    private String rango;
    private String tecnica;

    public Demonio(String nombre, int nivel, String rango, String tecnica) {
        this.nombre = nombre;
        this.nivel = nivel;
        this.rango = rango;
        this.tecnica = tecnica;
        this.salud = 60 + (nivel * 10);
    }

    public String getNombre() { return nombre; }
    public int getSalud() { return salud; }
    public int getNivel() { return nivel; }
    public String getRango() { return rango; }
    public String getTecnica() { return tecnica; }

    public void atacar(Cazador j) {
        int daño = (int)(Math.random() * (nivel * 6 + 5));
        if (rango != null && rango.toLowerCase().contains("superior")) {
            daño += 5;
        }
        j.recibirDaño(daño);
    }

    public void recibirDaño(int d) {
        salud -= d;
        if (salud < 0) salud = 0;
    }

    @Override
    public String toString() {
        return nombre + " [" + rango + "] - " + tecnica + " (" + salud + " HP)";
    }
}
