package Vista3;

import Modelo3.Cazador;
import Modelo3.Demonio;
import Modelo3.Item;

import java.util.List;
import java.util.Scanner;

public class VistaBatalla {
    private Scanner sc = new Scanner(System.in);

    public void mostrarInicio(Cazador c, List<Demonio> demonios) {
        System.out.println("\n=== COMIENZA LA CAZA ===");
        System.out.println(c.getNombre() + " se prepara para enfrentar demonios:");
        for (int i = 0; i < demonios.size(); i++) {
            System.out.println("  " + (i+1) + ". " + demonios.get(i).getNombre() + " - " + demonios.get(i).getRango());
        }
    }

    public void mostrarEstado(Cazador c, List<Demonio> demonios) {
        System.out.println("\n[Estado]");
        System.out.println(c);
        System.out.println("Inventario:");
        int idx = 1;
        for (Item it : c.getInventario()) {
            System.out.println("  " + (idx++) + ". " + it);
        }
        System.out.println("Enemigos:");
        for (int i = 0; i < demonios.size(); i++) {
            Demonio d = demonios.get(i);
            System.out.println("  " + (i+1) + ". " + d.getNombre() + " - " + d.getSalud() + " HP (" + d.getTecnica() + ")");
        }
    }

    public void mostrarOpciones() {
        System.out.println("\nOpciones:");
        System.out.println("  1. Atacar con arma");
        System.out.println("  2. Usar poción");
        System.out.println("  3. Huir");
        System.out.print("Elige una opción: ");
    }

    public void mostrarInventario(List<Item> inventario) {
        System.out.println("\nInventario:");
        for (int i = 0; i < inventario.size(); i++) {
            System.out.println("  " + (i+1) + ". " + inventario.get(i));
        }
    }

    public int pedirIndiceObjeto() {
        System.out.print("Selecciona el número del objeto: ");
        String s = sc.nextLine();
        try {
            return Integer.parseInt(s);
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    public int pedirIndiceEnemigo() {
        System.out.print("Número del enemigo (1, 2, ...): ");
        String s = sc.nextLine();
        try {
            return Integer.parseInt(s);
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    public void mensaje(String msg) {
        System.out.println(msg);
    }

    public void mostrarResultado(Cazador c, List<Demonio> demonios) {
        boolean todosMuertos = true;
        for (Demonio d : demonios) if (d.getSalud() > 0) { todosMuertos = false; break; }

        System.out.println("\n=== RESULTADO ===");
        if (c.getSalud() <= 0) {
            System.out.println("Has sido derrotado...");
        } else if (todosMuertos) {
            System.out.println("¡Victoria! Todos los demonios han sido vencidos.");
            System.out.println("Nivel final del cazador: " + c.getNivel());
        } else {
            System.out.println("Te retiraste del combate.");
        }
    }
}

