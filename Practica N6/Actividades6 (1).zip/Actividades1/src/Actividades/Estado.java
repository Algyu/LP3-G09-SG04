package Actividades;

public enum Estado {
    PENDIENTE,
    COMPLETO,
    ELIMINADO
}