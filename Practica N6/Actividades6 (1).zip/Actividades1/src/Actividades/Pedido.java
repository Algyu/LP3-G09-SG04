package Actividades;

public class Pedido {
    private String nombrePlato;
    private String tipo;
    private Estado estado;

    public Pedido(String nombrePlato, String tipo) {
        this.nombrePlato = nombrePlato;
        this.tipo = tipo;
        this.estado = Estado.PENDIENTE;
    }

    public String getNombrePlato() { return nombrePlato; }
    public String getTipo() { return tipo; }
    public Estado getEstado() { return estado; }

    public void setEstado(Estado estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return nombrePlato + " (" + tipo + ") - " + estado;
    }
}
