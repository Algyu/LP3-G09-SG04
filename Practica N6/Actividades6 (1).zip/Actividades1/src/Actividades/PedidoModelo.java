package Actividades;

import java.util.ArrayList;
import java.util.List;

public class PedidoModelo {
    private List<Pedido> pedidos = new ArrayList<>();
    private List<Pedido> historial = new ArrayList<>();

    public void agregarPedido(Pedido p) {
        pedidos.add(p);
    }

    public boolean marcarCompleto(int index) {
        if (index >= 0 && index < pedidos.size()) {
            pedidos.get(index).setEstado(Estado.COMPLETO);
            historial.add(pedidos.get(index));
            return true;
        }
        return false;
    }

    public boolean eliminarPedido(int index) {
        if (index >= 0 && index < pedidos.size()) {
            Pedido eliminado = pedidos.remove(index);
            eliminado.setEstado(Estado.ELIMINADO);
            historial.add(eliminado);
            return true;
        }
        return false;
    }

    public List<Pedido> getPedidosPorEstado(Estado estado) {
        List<Pedido> lista = new ArrayList<>();
        for (Pedido p : pedidos) {
            if (p.getEstado() == estado) lista.add(p);
        }
        return lista;
    }

    public int contarPendientes() {
        int cont = 0;
        for (Pedido p : pedidos) {
            if (p.getEstado() == Estado.PENDIENTE) cont++;
        }
        return cont;
    }

    public List<Pedido> getPedidos() {
        return pedidos;
    }

    public List<Pedido> getHistorial() {
        return historial;
    }
}
