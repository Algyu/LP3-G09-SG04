package Actividades;

public class PedidoControlador {
    private PedidoModelo modelo;
    private PedidoVista vista;

    public PedidoControlador(PedidoModelo modelo, PedidoVista vista) {
        this.modelo = modelo;
        this.vista = vista;
    }

    public void iniciar() {
        int opcion;
        do {
            vista.menu();
            opcion = vista.leerOpcion();
            switch (opcion) {
                case 1:
                    String nombre = vista.pedirNombre();
                    String tipo = vista.pedirTipo();
                    modelo.agregarPedido(new Pedido(nombre, tipo));
                    vista.mostrarMensaje("Pedido agregado!");
                    break;
                case 2:
                    vista.mostrarPedidos(modelo.getPedidos());
                    break;
                case 3:
                    vista.mostrarPedidos(modelo.getPedidos());
                    int iComp = vista.pedirIndice();
                    if (modelo.marcarCompleto(iComp))
                        vista.mostrarMensaje("Pedido marcado como completo!");
                    else
                        vista.mostrarMensaje("Índice inválido.");
                    break;
                case 4:
                    vista.mostrarPedidos(modelo.getPedidos());
                    int iDel = vista.pedirIndice();
                    if (modelo.eliminarPedido(iDel))
                        vista.mostrarMensaje("Pedido eliminado!");
                    else
                        vista.mostrarMensaje("Índice inválido.");
                    break;
                case 5:
                    Estado est = vista.pedirEstado();
                    vista.mostrarPedidos(modelo.getPedidosPorEstado(est));
                    break;
                case 6:
                    vista.mostrarMensaje("Pedidos pendientes: " + modelo.contarPendientes());
                    break;
                case 7:
                    vista.mostrarMensaje("Historial de pedidos:");
                    vista.mostrarPedidos(modelo.getHistorial());
                    break;
                case 8:
                    vista.mostrarMensaje("Saliendo...");
                    break;
                default:
                    vista.mostrarMensaje("Opción inválida.");
            }
        } while (opcion != 8);
    }
}
