package Actividades;

import java.util.List;
import java.util.Scanner;

public class PedidoVista {
    private Scanner sc = new Scanner(System.in);

    public String pedirNombre() {
        System.out.print("Nombre del plato: ");
        return sc.nextLine();
    }

    public String pedirTipo() {
        System.out.print("Tipo del plato: ");
        return sc.nextLine();
    }

    public int pedirIndice() {
        System.out.print("Número del pedido: ");
        return Integer.parseInt(sc.nextLine());
    }

    public Estado pedirEstado() {
        System.out.print("Estado (PENDIENTE/COMPLETO/ELIMINADO): ");
        try {
            return Estado.valueOf(sc.nextLine().toUpperCase());
        } catch (Exception e) {
            return null;
        }
    }

    public void mostrarPedidos(List<Pedido> pedidos) {
        if (pedidos.isEmpty()) {
            System.out.println("No hay pedidos.");
        } else {
            for (int i = 0; i < pedidos.size(); i++) {
                System.out.println(i + ". " + pedidos.get(i));
            }
        }
    }

    public void menu() {
        System.out.println("\n=== MENÚ ===");
        System.out.println("1. Agregar pedido");
        System.out.println("2. Mostrar todos");
        System.out.println("3. Marcar pedido como completo");
        System.out.println("4. Eliminar pedido");
        System.out.println("5. Mostrar pedidos por estado");
        System.out.println("6. Contador de pendientes");
        System.out.println("7. Mostrar historial");
        System.out.println("8. Salir");
        System.out.print("Elige opción: ");
    }

    public int leerOpcion() {
        return Integer.parseInt(sc.nextLine());
    }

    public void mostrarMensaje(String msg) {
        System.out.println(msg);
    }
}
